'''
Fichier contenant des fonctions pour des calculs génériques.

Author : Matthew, Romain
Date : 16/03/2026
Python version : 3.12.12
'''

from panda3d.core import TextNode
from math import sqrt

def is_in_area(start_pos:tuple[float, float, float], end_pos:tuple[float, float, float], target) -> bool:
        """
        Vérifie qu'une target donnée est dans une zone comprise entre start_pos et end_pos
        
        start_pos, end_pos (tuple[float, float, float]) : respectivement les points de début et de fin d'un cube
        target (NodePath) : l'objet dont la position sera testée
        """
        start_x, start_y, start_z = start_pos
        end_x, end_y, end_z = end_pos
        assert start_x < end_x, "start_x superieur à end_x"
        assert start_y < end_y, "start_y superieur à end_y"
        assert start_z < end_z, "start_z superieur à end_z"
        return (start_x <= target.getX() <= end_x) and (start_y <= target.getY() <= end_y) and (start_z <= target.getZ() <= end_z)


def dist_A_B(A:tuple[int, int, int], B:tuple[int, int, int]):
    return sqrt((A[0] - B[0]) * (A[0] - B[0]) + (A[1] - B[1]) * (A[1] - B[1]) + (A[2] - B[2]) * (A[2] - B[2])) # sqrt (x_{B} - x_{A})^2 + (y_{B} - y_{A})^2) et aussi pour les Z

def create_text(parent, name:str, text:str, pos:tuple[int, int, int]):
    """
    Créé un texte à la position donnée et l'affiche. Retourne le nœud chemin vers le texte et le nœud du texte.

    parent (NodePath) : où attacher le noeud du texte (habituellement render2d)
    name (str) : le nom du nodepath
    text (str) : le texte affiché
    pos (tuple[int, int, int]) : la position du texte sur l'écran
    """
    title_text = TextNode(name)
    title_text.setText(text)
    title_text.setSmallCaps(True)
    textNodePath = parent.attachNewNode(title_text)
    textNodePath.setScale(0.08)
    textNodePath.setPos(pos)
    return textNodePath, title_text
