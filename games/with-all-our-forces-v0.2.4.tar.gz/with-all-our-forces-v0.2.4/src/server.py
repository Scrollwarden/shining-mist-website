
'''
This file contain all the program to run the game server-side.

Author : Matthew
Date : 17/11/2025
Python version : 3.12.12
'''

# libs de panda3D
from panda3d.core import QueuedConnectionManager, QueuedConnectionReader, ConnectionWriter, NetDatagram, DatagramIterator, NetAddress
from direct.task import Task

# Nos fichiers
from src.constants import *

# === Programme ===
# classes

class Server():
    '''
    La partie du jeu gérée par le server.
    Le server broadcast un heartbeat jusqu'à atteindre le bon nombre de clients connectés,
    puis se contente de transférer les données de chaque client aux autres.
    Il broadcast un appel à déconnexion si il est stoppé, forçant tous les clients à quitter.
    '''
    def __init__(self, showbase, name):
        self.name = name
        self.manager = showbase.taskMgr
        self.terminate = False

        self.ip = 'localhost' if LOCAL_TEST else '0.0.0.0'
        self.port = CLIENT_PORT + 1 # taking the next port as client will also run

        self.known_str_address_list:list[tuple[str, int]] = []
        self.client1_timeout = 0
        self.client2_timeout = 0

        self._init_networking()
        self._set_tasks()

    def _set_tasks(self):
        """Définit toutes les tâches que le jeu pourra prendre en compte durant son exécution."""
        self.manager.add(self._task_pulse, "searchPlayer")
        self.manager.add(self._task_receive_and_read, "pollReader")

    # ============================
    # Networking part
    # ============================

    def _init_networking(self):
        """met en place les attributs nécessaires pour le networking"""
        self.coManager = QueuedConnectionManager()
        self.coReader = QueuedConnectionReader(self.coManager, 0)
        self.coWriter = ConnectionWriter(self.coManager, 0)

        # opening a new connection in addition from the one created at the game start
        self.connection = self.coManager.openUDPConnection(self.ip, self.port, for_broadcast=True)
        # Maybe we should listen on all ports, but currently all clients knows the server address and target it on send.
        self.coReader.addConnection(self.connection)
        if self.connection and DEBUG_NETWORK_LOGS:
            print(f"SERVER : Connected on port {self.port}...")

    def _task_pulse(self, task):
        """Broadcast un message de vie tant que moins de 2 clients sont connectés"""
        if self.terminate:
            return Task.done
        
        if len(self.known_str_address_list) < 2:
            # TODO : tant que le server est dans cet état, le client ne doit pas faire tourner le jeu
            datagram = NetDatagram()
            datagram.addString(SERVER_ALIVE_MESSAGE)
            datagram.addString(self.name)

            true_broadcast = NetAddress()
            true_broadcast.setHost('localhost' if LOCAL_TEST else LAN_ADDRESS, CLIENT_PORT)
            self.coWriter.send(datagram, self.connection, true_broadcast, block=False)

            if DEBUG_NETWORK_ALL_LOGS:
                print(f"SERVER : plused as {self.name} on {true_broadcast}.")

            return Task.cont
        
        else:
            return Task.done
    
    def _task_receive_and_read(self, task):
        """Le lecteur de réseau récupère et lit le contenu des datagrams reçus sur le port écouté par le server."""
        if self.terminate:
            return Task.done
        
        while self.coReader.dataAvailable():
            datagram = NetDatagram()
            if self.coReader.getData(datagram):
                # register new connection
                datagram_address = datagram.getAddress()
                data_iterator = DatagramIterator(datagram)
                message = data_iterator.getString()
                if DEBUG_NETWORK_ALL_LOGS:
                    print(f"SERVER : Recevied {message} from {datagram_address}")
                
                client_ip_and_port = (datagram_address.getIpString(), datagram_address.getPort())
                if not client_ip_and_port in self.known_str_address_list:
                    self.known_str_address_list.append(client_ip_and_port) # NetAddress class get destroyed by panda3d's garbage collector.
                    if DEBUG_NETWORK_LOGS:
                        print(f"SERVER : Registered new connection from {datagram_address}.")

                # process the data
                if CLIENT_DISCONNECT_MESSAGE in message:
                    print(f"SERVER : {datagram_address} disconnected.")
                    self.known_str_address_list.remove(client_ip_and_port)
                    self._transfer_player_message(datagram, debug_head=CLIENT_DISCONNECT_MESSAGE)
                elif CLIENT_GAME_STATE_MESSAGE in message or PLAYER_DATA_MESSAGE in message \
                        or LEVEL_DATA_MESSAGE in message or ACTIVATIONS_DATA_MESSAGE in message:
                    self._transfer_player_message(datagram, source=client_ip_and_port, debug_head=PLAYER_DATA_MESSAGE)
                elif CLIENT_GREET_MESSAGE in message:
                    if DEBUG_NETWORK_LOGS:
                        print(f"SERVER : has received greetings by {datagram_address}")
                else:
                    print("SERVER : WARN : Recevied unrecognized data")
        
        return Task.cont

    def _transfer_player_message(self, datagram, source:tuple[str, int]=None, debug_head=None):
        """envoie le message d'un joueur à tous les autres clients"""
        # might need it in case some specific flags have to be proceeded differently.
        self._broadcast_message(datagram, exception=source, debug_head=debug_head)

    def _broadcast_message(self, datagram, exception:tuple[str, int]=None, debug_head=None):
        """Envoie le datagram donné à tous les clients connectés, sauf à la connection <exception> si elle est précisée."""
        for client_ip_and_port in self.known_str_address_list:
            if client_ip_and_port != exception:
                client_address = NetAddress()
                ip, port = client_ip_and_port
                client_address.setHost(ip, port)
                self.coWriter.send(datagram, self.connection, client_address, block=False)
        
        if DEBUG_NETWORK_ALL_LOGS and not debug_head is None:
            excepted = "." if not exception else f" at all except {exception}."
            print(f"SERVER : Broadcasted {debug_head}{excepted}")
            
    def disconnect_all(self):
        """Envoie un message de déconnexion à tous les clients puis s'éteint"""
        if DEBUG_NETWORK_LOGS:
            print("SERVER : Disconnection.")
        datagram = NetDatagram()
        datagram.addString(SERVER_DISCONNECT_MESSAGE)
        self._broadcast_message(datagram)
        self.coManager.closeConnection(self.connection)
        self.terminate = True
        if DEBUG_NETWORK_LOGS:
            print(f"SERVER : Freed {self.connection} on port {self.port} and disconnected.")
