'''
This file contain all the program to run the game client-side.

Author : Matthew
Date : 17/11/2025
Python version : 3.12.12
'''

# libs de panda3D
from direct.task import Task

from panda3d.core import NetDatagram, DatagramIterator, NetAddress
from panda3d.core import QueuedConnectionManager, QueuedConnectionReader, ConnectionWriter

# Nos fichiers
from src.game import Game
from src.constants import *

# === Programme ===
# classes

class Client:
    '''
    La partie du jeu gérée par le client.
    Le client cherche les servers en ligne sur sa LAN jusqu'à ce que le joueur le connecte.
    Une fois connecté, il transmet ses informations au server, et met à jour l'environnement
    affiché (toute la partie "jeu" est gérée ici) en fonction des données reçues du server.
    Envoie un message de déconnexion au server si il est stoppé.
    '''
    def __init__(self, showbase):
        self.manager = showbase.taskMgr

        self.port = CLIENT_PORT
        self.server_address = None
        self.is_host = False
        self.connected_to_server = False
        self.open_servers_dict:dict[tuple[str, int], str] = {} # (ip, port): name

        self.game = Game(showbase)

        self.distant_running = True # might avoid interlocking on game start
        self.distant_dead = False

        self._set_network()
        self.manager.add(self._task_receive_and_read, "data reader") # must be set up before the game run

    def _set_tasks(self, as_host):
        """Définit toutes les tâches que le client exécute à chaque frame. Appelé avec set_server_ip qui lance le jeu."""
        if as_host:
            self.manager.add(self._task_send_level_updates, "level data sender")
        else:
            self.manager.add(self._task_send_activations, "activations data sender")
        self.manager.add(self._task_send_game_state, "game state sender")
        self.manager.add(self._task_send_player_data, "player data sender")

    def _set_network(self):
        """met en place les attributs nécessaires pour le networking"""
        self.coManager = QueuedConnectionManager()
        self.coReader = QueuedConnectionReader(self.coManager, 0)
        self.coWriter = ConnectionWriter(self.coManager, 0)

        if LOCAL_TEST:
            self.port = int(input("DEBUG : enter new base port... "))
        self.connection = self.coManager.openUDPConnection('0.0.0.0', self.port, for_broadcast=False)
        # 0.0.0.0 mean listening on all addresses as we can't say on which one the datagram will dock.
        if self.connection:
            self.coReader.addConnection(self.connection)
            if DEBUG_NETWORK_LOGS:
                print(f"CLIENT : Scanning for servers on port {self.port}...")
    
    def set_server_ip(self, server_ip, as_host=False):
        """
        Donne l'ip du serveur au client, définit le rôle du client, et démarre le jeu.
        Si le client est HOST (le serveur tourne sur sa machine), il envoie les données physique de son monde.
        Si le client est INVITE, il envoie les activations qu'il effectue, sans modifier son monde.

        Le jeu se met en marche dès que le serveur est connu.
        """
        self.is_host = as_host
        self.server_address = NetAddress()
        self.server_address.setHost(server_ip, CLIENT_PORT + 1)
        if DEBUG_NETWORK_LOGS:
            print(f"CLIENT : Set server address to {self.server_address}. I am {'HOST' if as_host else 'INVITE'}.")
        self.connected_to_server = True
        self._send_specific_data(CLIENT_GREET_MESSAGE)
        self.game.start(as_host)
        self._set_tasks(as_host)
        
    # ============================
    # RECEIVE methods
    # ============================

    def _task_receive_and_read(self, task):
        """Interroge le lecteur de réseau qui récupère et lit les datagrams reçus"""
        while self.coReader.dataAvailable():
            datagram = NetDatagram()
            
            if self.coReader.getData(datagram):
                data_iterator = DatagramIterator(datagram)
                address = datagram.getAddress()
                message = data_iterator.getString()
                if DEBUG_NETWORK_ALL_LOGS:
                    print(f"CLIENT : Recevied {message} from {datagram.getAddress()}")

                # generic checking which is the same no matter the game state
                if CLIENT_GAME_STATE_MESSAGE in message:
                    self._update_distant_game_state(data_iterator)
                elif CLIENT_DISCONNECT_MESSAGE in message:
                    self.game.remove_connected_character()
                else:
                    # entering a more specific checking part
                    if self.game.is_running:
                        self._subtask_update_game(message, address, data_iterator)
                    else:
                        self._subtask_scan_LAN(message, address, data_iterator)

        return Task.cont

    def _subtask_scan_LAN(self, message, address, data_iterator):
        """
        Sous-tâche appellée par receive_and_read. C'est la partie de la tâche active tant que le serveur est inconnu.
        Récupère la liste de toutes les adresses des paquets reçus, afin de gérer la liste des serveurs actifs sur la LAN.
        """
        ip_port = (address.getIpString(), address.getPort())
        if SERVER_ALIVE_MESSAGE in message and not (ip_port in self.open_servers_dict):
            server_name = data_iterator.getString()
            self.open_servers_dict[ip_port] = server_name
            if DEBUG_NETWORK_LOGS:
                print(f"CLIENT : A new server is alive on {address}.")
        elif SERVER_DISCONNECT_MESSAGE in message and (ip_port in self.open_servers_dict):
            self.open_servers_dict.pop(ip_port)
            if DEBUG_NETWORK_LOGS:
                print(f"CLIENT : Server {address} closed.")

    def _subtask_update_game(self, message, address, data_iterator):
        """
        Sous-tâche appellée par receive_and_read. C'est la partie de la tâche active tant que le serveur est connu.
        Récupère toutes les informations du jeu du client distant envoyées par le serveur.
        """
        if SERVER_DISCONNECT_MESSAGE in message:
            if DEBUG_NETWORK_LOGS:
                print("CLIENT : disconnecting...")
            self.disconnect(from_server=True)
            self.open_servers_dict.pop((address.getIpString(), address.getPort()))
            if DEBUG_NETWORK_LOGS:
                print(f"CLIENT : Server {address} closed.")
        elif PLAYER_DATA_MESSAGE in message:
            self._update_connected_player(data_iterator)
        elif (not self.is_host) and LEVEL_DATA_MESSAGE in message:
            # INVITE met à jour son monde en fonction de celui de HOST
            self._update_current_level(data_iterator)
        elif self.is_host and ACTIVATIONS_DATA_MESSAGE in message:
            # HOST gère son monde en local en tenant compte des activations de INVITE
            self._update_distant_activations(data_iterator)
        elif SERVER_ALIVE_MESSAGE in message:
            if DEBUG_NETWORK_ALL_LOGS:
                print("CLIENT : Server is searching for more players")
        elif DEBUG_NETWORK_LOGS:
            print("CLIENT : WARN : Unrecognized data.")

    def _update_distant_game_state(self, data_iterator):
        """Met à jour les données connues du jeu distant et agit sur le jeu local en cas de besoin"""
        self.distant_running = data_iterator.getBool()
        if self.game.blocked_from_distant and self.distant_running:
            self.game.run(from_distant=True)
        elif not self.game.blocked_from_distant and not self.distant_running:
            self.game.stop(from_distant=True)
        self.distant_dead = data_iterator.getBool()
        if self.distant_dead and self.game.is_running:
            self.game.stop(from_distant=True)

    def _update_connected_player(self, data_iterator):
        """extrait les informations reçues pour le joueur et met à jour le personnage du client connecté"""
        x = data_iterator.getFloat32()
        y = data_iterator.getFloat32()
        z = data_iterator.getFloat32()
        h = data_iterator.getFloat32()
        p = data_iterator.getFloat32()
        r = data_iterator.getFloat32()
        light_on = data_iterator.getBool()

        if not self.game.connected_character:
            self.game.set_connected_character((x, y, z), (h, p, r))
            if DEBUG_NETWORK_LOGS:
                print("CLIENT : A new player connected.")
        else:
            self.game.update_connected_player((x, y, z), (h, p, r), light_on)

    def _update_current_level(self, data_iterator):
        """extrait les informations reçues de HOST et met à jour la carte (portes et champs de force) chez INVITE"""
        if self.is_host:   # guard supplémentaire, seul INVITE doit mettre à jour son monde en fonction des données distantes.
            return         # HOST gère l'état de son monde en local.
        if self.game.maploader.current_level != data_iterator.getInt32():
            return # avoid datagram of wrond lenght to be read, in case we receive an old datagram on level switch
        
        for door in self.game.maploader.list_porte:
            is_open = data_iterator.getBool()
            if is_open and not door.is_open:
                door.force_open()

        for forcefield in self.game.maploader.list_forcefield:
            h = data_iterator.getFloat32()
            p = data_iterator.getFloat32()
            forcefield.rotateTo(h, p)
            is_open = data_iterator.getBool()
            if is_open and not forcefield.is_open: # HOST has an open forcefield, and INVITE adapt.
                forcefield.open()
        
        for pnj in self.game.maploader.list_pnj:
            x = data_iterator.getFloat32()
            y = data_iterator.getFloat32()
            z = data_iterator.getFloat32()
            h = data_iterator.getFloat32()
            p = data_iterator.getFloat32()
            r = data_iterator.getFloat32()
            pnj.actor.setPos(x, y, z)
            pnj.actor.setHpr(h, p, r)

    def _update_distant_activations(self, data_iterator):
        """extrait les informations d'activations locales reçues de INVITE et les met à jour chez HOST."""
        if not self.is_host:   # guard supplémentaire, seul HOST doit mettre à jour les activations en fonction des données de INVITE.
            return             # INVITE n'ouvre jamais ses portes/forcefields mais les actives et attends le retour de HOST.
        if self.game.maploader.current_level != data_iterator.getInt32():
            return # avoid datagram of wrond lenght to be read, in case we receive an old datagram on level switch
        
        for door in self.game.maploader.list_porte:
            door.activated_at_distant = data_iterator.getBool()
            if not door.is_open:
                door.open() # Tries to open the door and succed only if all activations are done
        
        for forcefield in self.game.maploader.list_forcefield:
            active = data_iterator.getBool() # There is no further check. INVITE request activation, and HOST activate.
            if active and not forcefield.is_open: # When HOST activate, it open on it side (local handle)
                forcefield.open()
        
    # ============================
    # SEND methods
    # ============================

    def _task_send_game_state(self, task):
        """envoie les états du jeu local"""
        if not self.connected_to_server or not self.game.connected_character:
            return Task.cont # must wait for the other client to be connected before starting
        
        if self.connection and self.server_address:
            datagram = self._create_game_state_datagram()

            self.coWriter.send(datagram, self.connection, self.server_address, block=False)
            if DEBUG_NETWORK_ALL_LOGS:
                print(f"CLIENT : Sent {CLIENT_GAME_STATE_MESSAGE} to server at {self.server_address.getIpString()}")
        else:
            print(f"CLIENT : ERR : No server found !\n\tconnection : {'UP' if self.connection else 'DOWN'} | address : {self.server_address}")

        return Task.cont

    def _task_send_player_data(self, task):
        """envoie les coordonnées du joueur au server"""
        if not self.connected_to_server or not self.game.is_running:
            return Task.cont
        
        if self.connection and self.server_address:
            datagram = self._create_player_info_datagram()

            self.coWriter.send(datagram, self.connection, self.server_address, block=False)
            if DEBUG_NETWORK_ALL_LOGS:
                print(f"CLIENT : Sent {PLAYER_DATA_MESSAGE} to server at {self.server_address.getIpString()}")
        else:
            print(f"CLIENT : ERR : No server found !\n\tconnection : {'UP' if self.connection else 'DOWN'} | address : {self.server_address}")

        return Task.cont
    
    def _task_send_activations(self, task):
        """Le client INVITE envoie les états d'activations des portes au client HOST."""
        if not self.connected_to_server or not self.game.is_running or self.is_host:
            return Task.cont
        
        if self.connection and self.server_address:
            datagram = self._create_activations_datagram()

            self.coWriter.send(datagram, self.connection, self.server_address, block=False)
            if DEBUG_NETWORK_ALL_LOGS:
                print(f"CLIENT : Sent {ACTIVATIONS_DATA_MESSAGE} to server at {self.server_address.getIpString()}")
        else:
            print(f"CLIENT : ERR : No server found !\n\tconnection : {'UP' if self.connection else 'DOWN'} | address : {self.server_address}")
        
        return Task.cont
    
    def _task_send_level_updates(self, task):
        """Le client HOST envoie les états de positions du niveau au client INVITE."""
        if not self.connected_to_server or not self.game.is_running or not self.is_host:
            return Task.cont
        
        if self.connection and self.server_address:
            datagram = self._create_level_info_datagram()

            self.coWriter.send(datagram, self.connection, self.server_address, block=False)
            if DEBUG_NETWORK_ALL_LOGS:
                print(f"CLIENT : Sent {LEVEL_DATA_MESSAGE} to server at {self.server_address.getIpString()}")
        else:
            print(f"CLIENT : ERR : No server found !\n\tconnection : {'UP' if self.connection else 'DOWN'} | address : {self.server_address}")
        
        return Task.cont

    def _send_specific_data(self, specific_head, content:list=[]):
        """créé un datagram avec les données de content"""
        datagram = NetDatagram()
        datagram.addString(specific_head)
        for data in content:
            if type(data) == str:
                datagram.addString(data)
            elif type(data) == int:
                datagram.addInt32(data)
            elif type(data) == float:
                datagram.addFloat32(data)
            else:
                datagram.addString(f"{data}")
        
        if self.connection and self.server_address:
            self.coWriter.send(datagram, self.connection, self.server_address, block=False)
            if DEBUG_NETWORK_ALL_LOGS:
                print(f"CLIENT : Sent {specific_head} to server at {self.server_address.getIpString()}")
        else:
            print(f"CLIENT : ERR : No server found !\n\tconnection : {'UP' if self.connection else 'DOWN'} | address : {self.server_address}")

    def _create_game_state_datagram(self):
        """Créé une donnée contenant les infos du jeu"""
        datagram = NetDatagram()
        datagram.addString(CLIENT_GAME_STATE_MESSAGE)
        datagram.addBool(self.game.blocked_from_distant or self.game.is_running)
        datagram.addBool(self.game.is_dead)
        return datagram

    def _create_player_info_datagram(self):
        """créé une donnée contenant les infos du joueur"""
        datagram = NetDatagram()
        (x, y, z), (h, p, r), light_on = self.game.get_player_info()
        datagram.addString(PLAYER_DATA_MESSAGE)
        datagram.addFloat32(x)
        datagram.addFloat32(y)
        datagram.addFloat32(z)
        datagram.addFloat32(h)
        datagram.addFloat32(p)
        datagram.addFloat32(r)
        datagram.addBool(light_on)
        return datagram
    
    def _create_level_info_datagram(self):
        """Créé une donnée contenant les infos de position du niveau"""
        datagram = NetDatagram()
        datagram.addString(LEVEL_DATA_MESSAGE)

        datagram.addInt32(self.game.maploader.current_level)

        for is_open in self.game.yield_door_position():
            datagram.addBool(is_open)
            
        for (h, p), is_open in self.game.yield_forcefield_position():
            datagram.addFloat32(h)
            datagram.addFloat32(p)
            datagram.addBool(is_open)

        for (x, y, z), (h, p, r) in self.game.yield_pnj_position():
            datagram.addFloat32(x)
            datagram.addFloat32(y)
            datagram.addFloat32(z)
            datagram.addFloat32(h)
            datagram.addFloat32(p)
            datagram.addFloat32(r)

        return datagram
    
    def _create_activations_datagram(self):
        """Créé une donnée contenant les infos d'activation des portes du niveau"""
        datagram = NetDatagram()
        datagram.addString(ACTIVATIONS_DATA_MESSAGE)

        datagram.addInt32(self.game.maploader.current_level)

        for activated_on_our_side in self.game.yield_door_activation():
            datagram.addBool(activated_on_our_side)
        
        for activated_on_our_side in self.game.yield_forcefield_activation():
            datagram.addBool(activated_on_our_side)
        
        return datagram
    
    def disconnect(self, from_server=False):
        """
        Déconnecte proprement le client du server.
        Doit gérer le cas où le server déconnecte le client et celui où le client se déconnecte lui-même.
        """
        if (not from_server) and self.connection:
            datagram = NetDatagram()
            datagram.addString(CLIENT_DISCONNECT_MESSAGE)
            self.coWriter.send(datagram, self.connection, self.server_address, Block=False)
            if DEBUG_NETWORK_ALL_LOGS:
                print(f"CLIENT : Sent {CLIENT_DISCONNECT_MESSAGE} to server")
        self.server_address = None
        self.connected_to_server = False
        self.game.kill()
        if DEBUG_NETWORK_LOGS:
            print("CLIENT : disconnected.")
