'''
This file contain all the program that run the in-game part of the programm.

Author : Matthew, Noé, Ninon, Raphaël, Romain
Date : 29/03/2026
Python version : 3.12.12
'''
# libs de panda3D
from direct.task import Task

from panda3d.core import ClockObject, KeyboardButton, BitMask32
from panda3d.core import Vec3, CollisionTraverser, CollisionHandlerPusher, CollisionHandlerEvent, CollisionHandlerQueue

# Nos fichiers
from src.objects import EntityType, Player, PNJ
from src.maploader import MapLoader
from src.physics import setCollidebox, setGroundCollisionRay, set_interaction_capsule, set_interaction_zone
from src.utilities import is_in_area, create_text, dist_A_B
from src.constants import *

# === Programme ===
# classes

class Game:
    '''
    Gère toute la logique du jeu in-game. Le jeu est en pause par défaut.
    '''
    def __init__(self, showbase):
        self.is_host = False # indique si cette instance du jeu est contrôlée par un client HOST ou un INVITE
        self.is_running = False
        self.blocked_from_distant = False # indique si le jeu est bloqué par le distant, afin d'éviter les interblocages
        self.is_dead = False # indique si le joueur a été tué par un pnj

        showbase.cam.node().getLens().setFov(90)
        self.showbase = showbase # Still necessary for .accept(event), .win, and .mouseWatcher
        self.render = showbase.render
        self.render2d = showbase.render2d
        self.camera = showbase.camera
        self.manager = showbase.taskMgr
        self.preferences = showbase.preferences

        self.maploader = MapLoader(showbase)
        self.character = None
        self.connected_character = None

        self.clock = ClockObject.getGlobalClock()

    # ============================
    # Runner
    # ============================

    def start(self, as_host):
        """
        Run the game for the first time.
        Main difference with run() is that run() just reallow player to interact with the game,
        while start() load a level and setup all physics and interactions.
        """
        self.is_host = as_host
        self.is_running = False # the game will be waiting and will run when all players are connected
        self._set_all_texts()
        self.maploader.set_next_level()
        self._set_character(EntityType.CYBORG if as_host else EntityType.ALIEN)
        self._set_collisions()
        self._set_interactions()
        self._set_accepts()
        self._set_tasks()
        self.showbase.win.movePointer(0, 0, 0)
        self.character.update(SPAWN_CYBORG if self.character.name == EntityType.CYBORG else SPAWN_ALIEN, (-70, 0, 0))
        if DEBUG_GAME_LOGS:
            print("* Game started.")

    def run(self, from_distant=False):
        """Run the game"""
        self.showbase.win.movePointer(0, 0, 0)
        if from_distant:
            self.blocked_from_distant = False
        self.is_running = True
        if DEBUG_GAME_LOGS:
            print("* Game is running" + (" at distant." if from_distant else "."))

    def stop(self, from_distant=False):
        """stop the game without closing it."""
        self.is_running = False
        self.blocked_from_distant = from_distant
        if DEBUG_GAME_LOGS:
            print("* Game was stopped" + (" from distant." if from_distant else '.'))
    
    def kill(self):
        """stop the game and close it definitively."""
        self.is_running = False
        if DEBUG_GAME_LOGS:
            print("* Game was killed.")

    # ============================
    # setters
    # ============================

    def _set_accepts(self):
        """Définit tous les événements a observer"""
        # inputs
        self.showbase.accept("a", self._event_switch_light)
        if DEBUG_FREE_CAMERA:
            self.showbase.accept('t', self._DEBUG_tp_player)
    
    def _set_tasks(self):
        """Définit toutes les tâches que le jeu exécutera à chaque frame"""
        if DEBUG_FREE_CAMERA:
            self.manager.add(self._DEBUG_task_move_camera, "debug camera movement")
            self.manager.add(self._DEBUG_task_rotate_camera, "debug camera rotation")
        else:
            self.manager.add(self._task_move_player, "player movement")
            self.manager.add(self._task_rotate_player, "player rotation")
        self.manager.add(self._task_handle_gravity, 'Gravity')
        self.manager.add(self._task_check_changing_level, 'level changing')
        self.manager.add(self._task_handle_collisions, 'Collisions')
        self.manager.add(self._task_animate_forcefield, 'animations forcefield')
        if self.is_host:
            self.manager.add(self._task_update_ai, "AI Update")

    def _set_all_texts(self):
        self.interaction_text, _ = create_text(self.render2d, 'interaction_button', "Press [E]", (-0.09, 0, -0.5))
        self.interaction_text.hide()

        if DEBUG_SHOW_COORDINATES:
            text_node, self.debug_camera_coord_text = create_text(self.render2d, 'debug camera pos', "Position : Not found.", (-0.95, 0, 0.65))
            text_node.setScale(0.04)
            text_node, self.debug_camera_hpr_text = create_text(self.render2d, 'debug camera hpr', "Look at : Not found", (-0.95, 0, 0.6))
            text_node.setScale(0.04)

    def _set_character(self, name:EntityType):
        """create a player-character with given name"""
        self.character = Player(name, SPAWN_CYBORG if name == EntityType.CYBORG else SPAWN_ALIEN, (-70, 0, 0), 0.5)
        self.character.actor.reparentTo(self.render)
        if DEBUG_FREE_CAMERA:
            self.camera.reparentTo(self.render)
            self.camera.setPos(0, 0, 0)
        else:
            self.camera.reparentTo(self.character.actor)
            self.camera.setPos(-1, -4.5, 2.5)
            self.camera.lookAt((0, 2.5, 1.5))
        if DEBUG_SHOW_COORDINATES:
            text_node, _ = create_text(self.render2d, 'debug character infos', f"Character : {self.character.name}", (-0.95, 0, 0.7))
            text_node.setScale(0.04)
        if DEBUG_PLAYERS_LOGS:
            print(f"** (local player) character created as {f'Cyborg at {SPAWN_CYBORG}' if name == EntityType.CYBORG else f'Alien at {SPAWN_ALIEN}'}")
    
    def set_connected_character(self, pos, hpr):
        """Créé un nouveau personnage connecté"""
        self.connected_character = Player((EntityType.ALIEN if self.character.name == EntityType.CYBORG else EntityType.CYBORG), pos, hpr, 0.5)
        self.connected_character.actor.reparentTo(self.render)
        self.render.setLight(self.connected_character.vision_light)
        if DEBUG_PLAYERS_LOGS:
            print(f"** (distant player) character created as {self.connected_character.name} at {pos}")
    
    def remove_connected_character(self):
        """Retire l'image du joueur connecté du jeu"""
        self.render.clearLight(self.connected_character.vision_light)
        self.connected_character.destroy()
        self.connected_character = None
        if DEBUG_PLAYERS_LOGS:
            print(f"** (distant player) character destroyed.")

    def _set_collisions(self):
        """Met en place toutes les collisions du jeu"""
        self.cTrav = CollisionTraverser()
        self.playerCollisionHandler = CollisionHandlerPusher() # pusher handle collision with walls
        self.groundHandler = CollisionHandlerQueue()

        if DEBUG_SHOW_COLLIDERS:
            self.cTrav.showCollisions(self.render)

        # collisions du joueur au sol
        groundRayNodePath = setGroundCollisionRay(self.character.actor)
        self.cTrav.addCollider(groundRayNodePath, self.groundHandler)

        # boîte de collision du joueur
        playerCollisionNode = setCollidebox(self.character.actor, (1, 1, 1), 0)
        playerCollisionNode.node().setFromCollideMask(BitMask32.bit(0))
        playerCollisionNode.node().setIntoCollideMask(BitMask32.allOff())
        self.playerCollisionHandler.addCollider(playerCollisionNode, self.character.actor)
        self.cTrav.addCollider(playerCollisionNode, self.playerCollisionHandler)

    def _set_interactions(self):
        """Définit les interactions du jeu"""
        self.interaction_allowed = False
        self.interaction_handler = CollisionHandlerEvent()

        # boite de collision d'interactions du joueur
        playerInteractionCollisionNode = setCollidebox(self.character.actor, (0.5, 0.5, 0.5), 0)
        playerInteractionCollisionNode.node().setFromCollideMask(BitMask32.bit(1))
        playerInteractionCollisionNode.node().setIntoCollideMask(BitMask32.allOff())
        self.cTrav.addCollider(playerInteractionCollisionNode, self.interaction_handler)

        # boite de collision de champ de force du joueur
        playerInteractionCollisionNode = setCollidebox(self.character.actor, (0.5, 0.5, 0.5), 0)
        playerInteractionCollisionNode.node().setFromCollideMask(BitMask32.bit(2))
        playerInteractionCollisionNode.node().setIntoCollideMask(BitMask32.allOff())
        self.cTrav.addCollider(playerInteractionCollisionNode, self.interaction_handler)
        
        # Événements d'interactions
        self.interaction_handler.addAgainPattern("inside-%in")
        self.interaction_handler.addInPattern("enter-%in")
        self.interaction_handler.addOutPattern("exit-%in")
    #     # les interactions sont appliquées aux chargements des niveaux
        
    # def _apply_interactions_on_level(self):
    #     """Applique les interactions aux objets chargés par le niveau"""
        for panel in self.maploader.list_panel:
            set_interaction_zone(panel.actor, self.render, 1.35, 1)
            self.showbase.accept(f"enter-{panel.actor.getName()}", self._event_enter_panel_area, [panel])
            self.showbase.accept(f"inside-{panel.actor.getName()}", self._event_when_inside_panel, [panel])
            self.showbase.accept(f"exit-{panel.actor.getName()}", self._event_exit_panel_area, [panel])

        for forcefield in self.maploader.list_forcefield:
            set_interaction_capsule(forcefield.main_actor, self.render, FORCEFIELD_MODEL_LEN, 2)
            self.showbase.accept(f"inside-{forcefield.main_actor.getName()}", self._event_when_inside_forcefield, [forcefield])
            for sub_forcefield in forcefield.sub_actors_list:
                set_interaction_capsule(sub_forcefield, self.render, FORCEFIELD_MODEL_LEN, 2)
                self.showbase.accept(f"inside-{sub_forcefield.getName()}", self._event_when_inside_forcefield, [forcefield])

    # ============================
    # Events / Inputs
    # ============================

    def _event_when_inside_forcefield(self, forcefield, collisionEntry):
        """Met à jour la position du joueur lorsqu'il est dans le champs de force"""
        if forcefield.is_open and self.character.name == EntityType.ALIEN:
            x, y, z = self.character.getPos()
            vx, vy, vz = forcefield.getForwardVector()
            self.character.actor.setPos(x + vx * forcefield.push, y + vy * forcefield.push, z + vz * forcefield.push)
            self.character.vertical_speed = FORCEFIELD_GRAVITY

    def _event_switch_light(self):
        if not self.character.power_light:
            # self.character.vision_light.setShadowCaster(True, 512, 512)###
            self.render.setLight(self.character.vision_light)
            # self.render.setShaderAuto()###
        else:
            self.render.clearLight(self.character.vision_light)
            # self.character.vision_light.setShadowCaster(False, 512, 512)###
            # self.render.clearShaderAuto()###
        self.character.power_light = not self.character.power_light

    def _event_enter_panel_area(self, panel, CollisionEntry):
        if self.character.name == panel.linked_character:
            panel.control.enable_activation()
            self.interaction_text.show()

    def _event_exit_panel_area(self, panel, CollisionEntry):
        if self.character.name == panel.linked_character:
            panel.control.disable_activation()
            self.interaction_text.hide()

    def _event_when_inside_panel(self, panel, CollisionEntry):
        is_pressed_ascii = lambda key : self.showbase.mouseWatcherNode.is_button_down(KeyboardButton.ascii_key(key))
        if is_pressed_ascii('e') and panel.control.is_activable():
            if DEBUG_GAME_LOGS:
                print(f"* Interaction with {panel.actor.getName()}...")
            panel.control.activate()
            #if self.is_host: # TODO : should be only host but currently hasty-patch an issue with forcefields.
            panel.control.open()

    # ============================
    # Checkers / Getters
    # ============================

    def get_player_info(self):
        """retourne les informations d'états du joueur géré par cette instance"""
        return self.character.getPos(), self.character.getHpr(), self.character.power_light
    
    def get_connected_player_info(self):
        """retourne les informations d'états du joueur connecté"""
        if self.connected_character:
            return self.connected_character.getPos(), self.connected_character.getHpr(), self.connected_character.power_light
        else:
            return None
        
    def yield_door_activation(self):
        """Itérateur sur les activations locales des portes"""
        for door in self.maploader.list_porte:
            yield door.activated_on_our_side
    
    def yield_door_position(self):
        """Itérateur sur les états physiques des portes (ouverture/fermeture)"""
        for door in self.maploader.list_porte:
            yield door.is_open

    def yield_forcefield_activation(self):
        """Itérateur sur les activations locales des champs de force"""
        for forcefield in self.maploader.list_forcefield:
            yield forcefield.active
    
    def yield_forcefield_position(self):
        """Itérateur sur les états physiques des champs de force"""
        for forcefield in self.maploader.list_forcefield:
            h, p, _ = forcefield.getHpr() # not sending roll coordinate which is just for local cool animation
            yield ((h, p), forcefield.is_open)

    def yield_pnj_position(self):
        """Itérateur sur les positions des IA"""
        for pnj in self.maploader.list_pnj:
            # TODO : pour l'instant seul la Cyborg peut être vue et le jeu continue chez l'Alien lorsque la Cyborg est vue.
            yield (pnj.getPos(), pnj.getHpr())
        
    def get_level_info(self) -> tuple[bool, bool]:
        """retourne les informations d'états du niveau"""
        return self.is_running, self.is_dead

    def _task_check_changing_level(self, task):
        """vérifie si les personnages sont au bon endroit pour changer de niveau et charge le niveau suivant si c'est le cas"""
        if self.character and self.connected_character and \
            is_in_area(self.maploader.pos_end_level[0], self.maploader.pos_end_level[1], self.character.actor) and \
            is_in_area(self.maploader.pos_end_level[0], self.maploader.pos_end_level[1], self.connected_character.actor):
            self.maploader.set_next_level()
            # self._apply_interactions_on_level()
        return Task.cont
    
    # ============================
    # Updaters
    # ============================

    def _task_animate_forcefield(self, task):
        """Appelle l'animation sur les champs de force."""
        for forcefield in self.maploader.list_forcefield:
            forcefield.barrel_roll()

        return Task.cont
    
    def update_connected_player(self, pos, hpr, light_on):
        """Met à jour les états du personnage connecté chaque tick"""
        if self.connected_character:
            h, p, r = hpr
            self.connected_character.update(pos, (h, 0, r))
            self.connected_character.cameraman.setP(p)
            if light_on: # should be improvable so we don't set the light each tick
                self.render.setLight(self.connected_character.vision_light)
            else:
                self.render.clearLight(self.connected_character.vision_light)
            if DEBUG_PLAYERS_ALL_LOGS:
                print(f"** (distant player) updated at {pos[0]:.2f}, {pos[1]:.2f}, {pos[2]:.2f}")

    def force_update_player(self, name, pos, hpr, light_on):
        """Force la mise à jour des états du personnage."""
        h, p, r = hpr
        self.character.name = name
        self.character.update(pos, (h, 0, r))
        self.character.cameraman.setP(p)
        self.character.power_light = light_on
        if DEBUG_PLAYERS_LOGS:
            print(f"** (local player) FORCE updated at {pos}")

    def force_update_connected_player(self, name, pos, hpr, light_on):
        """Force la mise à jour des états du personnage connecté."""
        self.set_connected_character(name, pos, hpr)
        self.connected_character.power_light = light_on

    def force_load_level(self, level_nb):
        """Force le chargement d'un niveau spécifique"""
        # TODO : mettre également à jour les champs de forces et portes modifiés
        match level_nb:
            case 1: self.maploader.set_level_1()
            case 2: self.maploader.set_level_2()
            case 3: self.maploader.set_level_3()
            case 4: self.maploader.set_level_4()
            case _: print(f"ERR : Trying to load level {level_nb} which does not exist.")
        if DEBUG_GAME_LOGS:
            print(f"* Loaded level {level_nb}")

    # ============================
    # Physics
    # ============================

    def _task_handle_gravity(self, task):
        """Modifie la vitesse verticale du joueur constamment."""
        if not self.is_running or DEBUG_DISABLE_GRAVITY:
            return Task.cont
        
        dt = self.clock.getDt()
        self.character.vertical_speed -= GRAVITY * dt
        self.character.actor.setZ(self.character.actor.getZ() + self.character.vertical_speed * dt)
        if self.character.actor.getZ() < -20:
            self.is_dead = True
            if DEBUG_GAME_LOGS:
                print("* Character fell too deep.")
            self.stop()
        return Task.cont

    def _task_handle_collisions(self, task):
        """Gère toutes les collisions."""
        if not self.is_running:
            return Task.cont
        
        # Collisions avec tout le reste
        self.cTrav.traverse(self.render)
        # Collisions avec le sol
        ground_collision_entries = self.groundHandler.getEntries()
        if ground_collision_entries:
            highest = max(ground_collision_entries, key=lambda e: e.getSurfacePoint(self.render).getZ())
            z_closest_ground = highest.getSurfacePoint(self.render).getZ()
            if self.character.actor.getZ() < z_closest_ground + 0.95:
                self.character.actor.setZ(z_closest_ground + 0.95)
                self.character.vertical_speed = 0

        return Task.cont

    # ============================
    # AI part
    # ============================

    def _task_update_ai(self, task):
        """Met à jour le monde relatif aux IA"""
        if not self.is_running: 
            return Task.cont
        for pnj in self.maploader.list_pnj:
            # Movement logic - currently prioritize cyborg over alien in the improbable case of a tie
            pnj.update(self.clock.getDt())
            if dist_A_B(pnj.actor.getPos(), self.character.getPos()) <= AI_DETECTION_RANGE:
                pnj.objectif = (self.character.actor.getX(), self.character.actor.getY(), 0)
            elif self.connected_character and dist_A_B(pnj.actor.getPos(), self.connected_character.getPos()) <= AI_DETECTION_RANGE:
                pnj.objectif = (self.character.actor.getX(), self.character.actor.getY(), 0)
            # Kill logic
            if (not DEBUG_DISABLE_AI_KILL) and (dist_A_B(pnj.actor.getPos(), self.character.getPos()) < AI_KILL_RANGE \
                or (self.connected_character and dist_A_B(pnj.actor.getPos(), self.connected_character.getPos()) < AI_KILL_RANGE)):
                self.is_dead = True
                if DEBUG_GAME_LOGS:
                    print("* One of the players got killed by a pnj.")
                self.stop()
        return Task.cont

    # ===========================
    # Movements
    # ============================

    def _task_move_player(self, task):
        """Task to move the player's actor in space."""
        if not self.is_running:
            return Task.cont

        dt = self.clock.getDt()
        move = Vec3(0, 0, 0)
        forward = self.character.actor.getQuat().getForward()
        forward = Vec3(forward.x, forward.y, 0) # disallow the camera to go in vertical direction.
        right = Vec3(forward.y, -forward.x, 0)
        # currently the x and y movements are reduced when looking up and down. Might not be an issue.
        is_pressed_ascii = lambda key : self.showbase.mouseWatcherNode.is_button_down(KeyboardButton.ascii_key(key))

        if is_pressed_ascii('z'):
            move += forward * CHARACTER_SPEED
        if is_pressed_ascii('q'):
            move -= right * CHARACTER_SPEED
        if is_pressed_ascii('s'):
            move -= forward * CHARACTER_SPEED
        if is_pressed_ascii('d'):
            move += right * CHARACTER_SPEED
        if self.showbase.mouseWatcherNode.is_button_down(KeyboardButton.space()):
            if self.character.vertical_speed == 0:
                self.character.vertical_speed = CHARACTER_JUMP_SPEED
        
        self.character.actor.setPos(self.character.actor.getPos() + move * dt)
        if DEBUG_SHOW_COORDINATES:
            x, y, z = self.character.getPos()
            self.debug_camera_coord_text.setText(f"Position : x = {x:.2f} | y = {y:.2f} | z = {z:.2f}")
        if DEBUG_PLAYERS_ALL_LOGS:
            x, y, z = self.character.getPos()
            print(f"** (local player) updated at {x:.2f}, {y:.2f}, {z:.2f}")
        return Task.cont

    def _task_rotate_player(self, task):
        """Task to handle the camera rotation with the mouse."""
        if (not (self.is_running and self.showbase.mouseWatcherNode.hasMouse())) or DEBUG_FREE_MOUSE:
            return Task.cont

        # already the delta from screen center (0, 0)
        mouse_x = self.showbase.mouseWatcherNode.getMouseX()
        mouse_y = self.showbase.mouseWatcherNode.getMouseY()

        self.character.actor.setH(self.character.actor.getH() - mouse_x * self.preferences['sensitivity'])
        camera_pitch = max(-89, min(89, self.camera.getP() + mouse_y * self.preferences['sensitivity']))
        self.camera.setP(camera_pitch)
        self.character.cameraman.setP(camera_pitch)
        self.showbase.win.movePointer(0, self.showbase.win.getXSize() // 2, self.showbase.win.getYSize() // 2)
        if DEBUG_SHOW_COORDINATES:
            h, p, r = self.camera.getHpr()
            self.debug_camera_hpr_text.setText(f"Look at : h = {h:.2f} | p = {p:.2f} | r = {r:.2f}")
        return Task.cont

    # ============================
    # DEBUG part
    # ============================

    def _DEBUG_task_move_camera(self, task):
        """Task to move the camera in space. Should only be used for debugging."""
        if not self.is_running:
            return Task.cont
        
        dt = self.clock.getDt()
        
        move = Vec3(0, 0, 0)
        forward = self.camera.getQuat().getForward()
        forward = Vec3(forward.x, forward.y, 0) # disallow the camera to go up when looking up.
        right = Vec3(forward.y, -forward.x, 0)
        up = Vec3(0, 0, 1)
        # currently the x and y movements are reduced when looking up and down.

        is_pressed_ascii = lambda key : self.showbase.mouseWatcherNode.is_button_down(KeyboardButton.ascii_key(key))

        if self.showbase.mouseWatcherNode.is_button_down(KeyboardButton.space()):
            move += up * DEBUG_CAMERA_SPEED
        if self.showbase.mouseWatcherNode.is_button_down(KeyboardButton.shift()):
            move -= up * DEBUG_CAMERA_SPEED
        if is_pressed_ascii('z'):
            move += forward * DEBUG_CAMERA_SPEED
        if is_pressed_ascii('q'):
            move -= right * DEBUG_CAMERA_SPEED
        if is_pressed_ascii('s'):
            move -= forward * DEBUG_CAMERA_SPEED
        if is_pressed_ascii('d'):
            move += right * DEBUG_CAMERA_SPEED
        
        self.camera.setPos(self.camera.getPos() + move * dt * 10)
        if DEBUG_SHOW_COORDINATES:
            x, y, z = self.camera.getPos()
            self.debug_camera_coord_text.setText(f"self position : x = {x:.2f} | y = {y:.2f} | z = {z:.2f}")
        return Task.cont
    
    def _DEBUG_task_rotate_camera(self, task):
        """Task to rotate the camera in space. Debug function."""
        if not (self.is_running and self.showbase.mouseWatcherNode.hasMouse()):
            return Task.cont

        # already the delta from screen center (0, 0)
        mouse_x = self.showbase.mouseWatcherNode.getMouseX()
        mouse_y = self.showbase.mouseWatcherNode.getMouseY()
        self.camera.setHpr(
            self.camera.getH() - mouse_x * self.preferences['sensitivity'],
            max(-89, min(89, self.camera.getP() + mouse_y * self.preferences['sensitivity'])),
            0)
        self.showbase.win.movePointer(0, self.showbase.win.getXSize() // 2, self.showbase.win.getYSize() // 2)
        if DEBUG_SHOW_COORDINATES:
            h, p, r = self.camera.getHpr()
            self.debug_camera_hpr_text.setText(f"Look at : h = {h:.2f} | p = {p:.2f} | r = {r:.2f}")
        return Task.cont
    
    def _DEBUG_tp_player(self):
        self.character.actor.setPos(self.camera.getPos())
        print(f"** (local player) FORCE updated via command [TP] at {self.camera.getPos()}")
