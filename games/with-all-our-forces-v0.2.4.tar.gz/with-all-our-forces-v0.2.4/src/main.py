'''
This is the main file the user will run in order to start the game.

Author : Matthew, Ninon
Date : 30/11/2025
Python version : 3.12.12
'''
# cannot be refactored because menus need to access main functions for the buttons

from enum import Enum

# libs de panda3D
from panda3d.core import WindowProperties, TextNode, TransparencyAttrib

from direct.showbase.ShowBase import ShowBase
from direct.gui.DirectGui import DirectButton, DirectEntry, DirectSlider
from direct.gui.OnscreenText import OnscreenText
from direct.gui.OnscreenImage import OnscreenImage
from direct.task import Task

# Nos fichiers
from src.client import Client
from src.server import Server
from src.constants import *
from src.utilities import create_text


# === Programme ===
# Classes

class GameState(Enum):
    STOPPED = 0
    PAUSED = 1
    WAITING = 2
    RUNNING = 3

class AllScreens(ShowBase):
    '''
    Classe des menus du jeu, a partir duquel il est possible de lancer
    une nouvelle partie ou de se connecter à une partie existante.
    Les menus sont les suivants :
    - main_screen : menu principal
    - parameters : menu accessible depuis le menu principal pour modifier certains paramètres.
    - menu_screen : menu intermédiaire premettant de sauvegarder une partie et de revenir à l'écran d'accueil
    '''
    def __init__(self):
        ShowBase.__init__(self)

        # Screen properties
        self.disableMouse()
        self._set_window()

        self.preferences = {'sensitivity': 80}

        self.server = None
        self.client = Client(self)
        self.server_name = '(anonym)'
        self.game_state = GameState.PAUSED
        if DEBUG_MAIN_LOOP_LOGS:
            print(f">> Status is {self.game_state}")

        self.buttons_maps = self.loader.loadModel(PATH_TO_BUTTON)

        self.main_screen_elements_list = []
        self.parameters_elements_list = []
        self.menu_screen_elements_list = []
        self.join_servers_buttons_list = []
        self._init_all_screens()
        self._show_main_screen()
        self._set_tasks()

    # ============================
    # Tasks
    # ============================

    def _set_tasks(self):
        self.accept('escape', self._escape_change_menu)
        self.taskMgr.add(self._task_check_server_full, "all players connected checker")
        self.taskMgr.add(self._task_check_games_running, "all games running checker")
    
    def _task_check_server_full(self, task):
        """
        Vérifie si le jeu est complet (dans le cas de son existence).
        Permet de forcer un écran d'attente tant qu'il manque au moins un joueur.
        Cet écran d'attente n'apparaît que chez HOST car INVITE n'a pas de serveur et rempli la condition en se connectant.
        """
        if self.game_state == GameState.RUNNING and self.server and len(self.server.known_str_address_list) < 2:
            self._show_waiting()
            if DEBUG_MAIN_LOOP_LOGS:
                print(f">> Server is waiting for more players. nb players : {len(self.server.known_str_address_list)}")
        elif self.game_state == GameState.WAITING and ((not self.server) or len(self.server.known_str_address_list) >= 2):
            if self.server and DEBUG_MAIN_LOOP_LOGS:
                print(f">> Server has enough players. nb players : {len(self.server.known_str_address_list)}")
            self._close_waiting()
            self.win.movePointer(0, 0, 0)
        return Task.cont

    def _task_check_games_running(self, task):
        """Vérifie que les jeux tournes et affiche des écrans de pause/mort/erreur associés dans le cas contraire"""
        if self.game_state == GameState.RUNNING and not self.client.game.is_running:
            if self.client.game.is_dead:
                self.game_state = GameState.PAUSED
                if DEBUG_MAIN_LOOP_LOGS:
                    print(f"Status is {self.game_state}")
                self._show_menu_screen()
                self.death_message.show()
                self.win.movePointer(0, 0, 0)
            elif self.client.distant_dead:
                print("distant client is dead.")
                self.game_state = GameState.PAUSED
                if DEBUG_MAIN_LOOP_LOGS:
                    print(f"Status is {self.game_state}")
                self._show_menu_screen()
                self.death_message_distant.show()
                self.win.movePointer(0, 0, 0)
            elif self.client.game.blocked_from_distant:
                print("distant client paused.")
                self.game_state = GameState.PAUSED
                if DEBUG_MAIN_LOOP_LOGS:
                    print(f"Status is {self.game_state}")
                self.waiter_node_path.show()
        elif self.game_state == GameState.PAUSED and self.client.game.is_running and not self.client.game.blocked_from_distant:
            self.waiter_node_path.hide()
            self.win.movePointer(0, 0, 0)
        return Task.cont

    # ============================
    # Graphic part
    # ============================

    def _set_window(self):
        """Met en place l'écran du jeu"""
        window_props = WindowProperties()
        window_props.setTitle(GAME_NAME)

        sizes = []

        # recupere la resolution de l'écran
        if not DEBUG_DISABLE_FULLSCREEN:
            display_info = self.pipe.getDisplayInformation()
            if display_info.getTotalDisplayModes() > 0:
                for index in range(display_info.getTotalDisplayModes()):
                    sizes += (display_info.getDisplayModeWidth(index), display_info.getDisplayModeHeight(index))
                if (len(sizes) > 0):
                    window_props.setSize(sizes[-2], sizes[-1]) #On suppose que c'est les deux plus grands
            else:
                window_props.setSize(1920, 1080)
                print("WARNING : couldn't get display size, set to 1920x1080 by default.")
        window_props.setFullscreen(not DEBUG_DISABLE_FULLSCREEN)
        self.win.requestProperties(window_props)
    
    def _init_all_screens(self):
        """Initialise tous les écrans du jeu"""
        # UI parameters
        window_props = WindowProperties()
        window_props.setCursorHidden(False)
        self.win.requestProperties(window_props)
        
        self.loader.loadFont(YRSA_SEMIBOLD)
        self._create_title()
        self._create_death_messages()
        self._init_main_screen()
        self._init_menu_screen()
        self._init_parameters()
        self._init_waiting()

    def _create_title(self):
        self.title_node_path = OnscreenImage(image=PATH_TO_TITLE_IMAGE, pos=(-0.4, 0, HIGHER_BUTTON_POS+0.4), scale=(1.25, 0, 0.25))
        self.title_node_path.setTransparency(TransparencyAttrib.MAlpha)
    
    def _create_death_messages(self):
        text = TextNode('death local')
        text.setText("Vous avez Péri.")
        self.death_message = self.render2d.attachNewNode(text)
        self.death_message.setPos(-0.5, 1, 0)
        self.death_message.setScale(0.1)
        self.death_message.hide()
        text = TextNode('death distant')
        text.setText("Votre coéquipier a Péri.")
        self.death_message_distant = self.render2d.attachNewNode(text)
        self.death_message_distant.setPos(-0.5, 1, 0)
        self.death_message_distant.setScale(0.1)
        self.death_message_distant.hide()

    # def _create_title(self):
    #     """Créé le titre du jeu"""
    #     title_text = TextNode('title')
    #     title_text.setText(GAME_NAME)
    #     title_text.setSmallCaps(True)
    #     title_text.font = self.loader.loadFont(YRSA_SEMIBOLD)
    #     title_text.setTextColor(159/255, 136/255, 103/255, 1) # beige color
    #     title_text.setShadow(0.05, 0.05)
    #     title_text.setShadowColor(0, 0, 0, 1) # black shadow
    #     title_text.set_frame_color(0, 0, 0, 1)
    #     title_text.set_frame_as_margin(0.05, 0.13, 0.03, -0.3)
    #     title_text.set_card_color(255, 255, 255, 0.3)
    #     title_text.set_card_as_margin(0.05, 0.13, 0.03, -0.3)
    #     self.title_node_path = self.render2d.attachNewNode(title_text)
    #     self.title_node_path.setScale(0.20)
    #     self.title_node_path.setPos(-0.92, -1.5, 0.75)

    def _init_main_screen(self):
        """Créé l'écran de menu principal"""
        def clear_text():
            server_name_entry.enterText('') # Wow this work !

        main_screen_background = OnscreenImage(image=PATH_TO_BACKGROUND_IMAGE, pos=(0, 0, 0), scale=(2, 0, 1), sort=-1)

        server_name_entry = DirectEntry(
            command=self._set_server_name,
            width=6,
            scale=0.097,
            initialText="Server name", 
            numLines = 1, 
            focus=0, 
            focusInCommand=clear_text,
            text_pos=(-3, -0.25),
            relief=None,
            geom=self.buttons_maps.find('**/new_game'),
            frameColor=(0, 0, 0, 0.2)
            )
        server_name_entry.setPos(-0.48, 0, HIGHER_BUTTON_POS)
        server_name_entry.setFrameColor()

        refresh_list_button = DirectButton(
            command=self._button_refresh_server_list,
            text=("Refresh", "Refreshing...", "- Refresh -", "disabled"),
            scale=0.09,
            text_pos=(0, -0.25),
            relief=None,
            geom=self.buttons_maps.find('**/new_game'),
            frameColor=(0, 0, 0, 0.2)
            )
        refresh_list_button.setPos(-0.508, 0, HIGHER_BUTTON_POS-0.3)

        new_game_button = DirectButton(
            command=self._button_create_new_game,
            text=("Open server", "Loading...", "- Open server -", "disabled"),
            scale=0.095,
            text_pos=(0, -0.25),
            relief=None,
            geom=self.buttons_maps.find('**/new_game'),
            frameColor=(0, 0, 0, 0.2)
            )
        new_game_button.setPos(-1.3, 0, HIGHER_BUTTON_POS)

        quit_button = DirectButton(
            command=self._button_quit_game,
            text=("Quit", "Closing...", "- Quit -", "disabled"),
            scale=0.09,
            text_pos=(0, -0.25),
            relief=None,
            geom=self.buttons_maps.find('**/new_game'),
            frameColor=(0, 0, 0, 0.2)
            )
        quit_button.setPos(1.35, 0, -0.85)

        parameter_button = DirectButton(
            command=self._show_parameters,
            text=("Parameters", "Loading...", "- Parameters -", "disabled"),
            scale=0.09,
            text_pos=(0, -0.25),
            relief=None,
            geom=self.buttons_maps.find('**/new_game'),
            frameColor=(0, 0, 0, 0.2)
            )
        parameter_button.setPos(1.35, 0, -0.55)
        # load_save_button stored in self because we need to access it on load to show/hide when a save file exist or don't
        self.load_save_button = DirectButton(
            command=self._button_load_save,
            text=("Load save", "Loading...", "- Load save -", "disabled"),
            scale=0.095,
            text_pos=(0, -0.25),
            relief=None,
            geom=self.buttons_maps.find('**/new_game'),
            frameColor=(0, 0, 0, 0.2)
            )
        self.load_save_button.setPos(1.3, 0, HIGHER_BUTTON_POS)

        self.main_screen_elements_list.append(main_screen_background)
        self.main_screen_elements_list.append(server_name_entry)
        self.main_screen_elements_list.append(refresh_list_button)
        self.main_screen_elements_list.append(new_game_button)
        self.main_screen_elements_list.append(quit_button)
        self.main_screen_elements_list.append(parameter_button)
        self.main_screen_elements_list.append(self.load_save_button)

    def _init_parameters(self):
        """Créé le menu de paramètres"""
        back_button = DirectButton(
            command=self._show_main_screen,
            text=("Back", ": Back :", "- Back -", "disabled"),
            scale=0.09,
            text_pos=(0, -0.25),
            relief=None,
            geom=self.buttons_maps.find('**/new_game'),
            frameColor=(0, 0, 0, 0.2)
            )
        back_button.setPos(1.35, 0, -0.55)
        self.sensitivity_slider = DirectSlider(
            range=(0, 100),
            value=80,
            pageSize=1,
            command=self._set_sensitivity
            )
        self.sensitivity_slider.setPos(0.7, 0, -0.2)

        self.sensitivity_text = OnscreenText(
            text=f"Sensitivity : {self.preferences['sensitivity']}",
            pos=(0.55, -0.32),
            scale=0.05,
            fg=(1, 1, 1, 1),
            align=TextNode.ALeft
            )
        
        self.parameters_elements_list.append(back_button)
        self.parameters_elements_list.append(self.sensitivity_slider)
        self.parameters_elements_list.append(self.sensitivity_text)

    def _init_menu_screen(self):
        """Affiche le  de pause"""
        resume_button = DirectButton(
            command=self._close_menu_screen,
            text=("Resume", "Resuming...", "- Resume -", "disabled"),
            scale=0.09,
            text_pos=(0, -0.25),
            relief=None,
            geom=self.buttons_maps.find('**/new_game'),
            frameColor=(0, 0, 0, 0.2)
            )
        resume_button.setPos(-1.3, 0, HIGHER_BUTTON_POS)
        save_button = DirectButton(
            command=self._button_save_game,
            text=("Save", "Saving...", "- Save -", "disabled"),
            scale=0.09,
            text_pos=(0, -0.25),
            relief=None,
            geom=self.buttons_maps.find('**/new_game'),
            frameColor=(0, 0, 0, HIGHER_BUTTON_POS-0.3)
            )
        save_button.setPos(-1.3, 0, 0)
        quit_to_main_screen_button = DirectButton(
            command=self._show_main_screen,
            text=("Disconnect", "Disconnecting...", "- Disconnect -", "disabled"),
            scale=0.09,
            text_pos=(0, -0.25),
            relief=None,
            geom=self.buttons_maps.find('**/new_game'),
            frameColor=(0, 0, 0, 0.2)
            )
        quit_to_main_screen_button.setPos(-1.3, 0, HIGHER_BUTTON_POS-0.8)

        self.menu_screen_elements_list.append(resume_button)
        self.menu_screen_elements_list.append(save_button)
        self.menu_screen_elements_list.append(quit_to_main_screen_button)

    def _init_waiting(self):
        """Écran affiché lorsqu'un joueur manque à l'appel"""
        waiting_text = TextNode('waiter text')
        waiting_text.setText("Waiting for the other player to connect...\n\n\tPress [escape] to disconnect.")
        waiting_text.setSmallCaps(True)
        waiting_text.font = self.loader.loadFont(YRSA_SEMIBOLD)
        waiting_text.setTextColor(1, 1, 1, 1)
        self.waiter_node_path = self.render2d.attachNewNode(waiting_text)
        self.waiter_node_path.setScale(0.05)
        self.waiter_node_path.setPos(-0.75, 0, 0)
        self.waiter_node_path.hide()

    def _show_main_screen(self):
        """Affiche le menu principal"""
        self._close_menu_to_main()
        self._close_parameters()
        for element in self.main_screen_elements_list:
            element.show()
        try : # Checking if a save file exist and displaying the button if yes
            file = open(SAVE_PATH, "r")
        except FileNotFoundError:
            self.load_save_button.hide()
        else:
            file.close()
        self._show_title_and_cursor()

    def _show_menu_screen(self):
        """Affiche le menu de pause"""
        if self.client.game.is_dead or self.client.distant_dead:
            self.menu_screen_elements_list[2].show() # not really clean but this access to back button
        else:
            for element in self.menu_screen_elements_list:
                element.show()
        self._show_title_and_cursor()

    def _show_parameters(self):
        """Affiche le menu paramètres"""
        for element in self.main_screen_elements_list[1:]:
            element.hide()
        for button in self.join_servers_buttons_list:
            button.hide()
            button.clear()
        for element in self.parameters_elements_list:
            element.show()
        self._show_title_and_cursor()

    def _show_waiting(self):
        """Affiche l'écran d'attente et met le jeu en pause"""
        self.client.game.stop()
        self.game_state = GameState.WAITING
        if DEBUG_MAIN_LOOP_LOGS:
            print(f">> Status is {self.game_state}")
        self.waiter_node_path.show()

    def _close_parameters(self):
        """Ferme le menu des paramètres pour revenir à l'écran principal"""
        for element in self.parameters_elements_list:
            element.hide()
        self._hide_title_and_cursor()

    def _close_menu_screen(self):
        """Ferme le menu de pause pour reprendre le jeu (différent si c'est pour rejoindre le menu principal)"""
        for element in self.menu_screen_elements_list:
            element.hide()
        self._hide_title_and_cursor()
        self.game_state = GameState.RUNNING
        if DEBUG_MAIN_LOOP_LOGS:
            print(f">> Status is {self.game_state}")
        self.client.game.run()
        
    def _close_main_screen(self):
        """efface l'écran avant d'afficher le client"""
        for button in self.main_screen_elements_list:
            button.hide()
        for button in self.join_servers_buttons_list:
            button.hide()
            button.clear()
        self._hide_title_and_cursor()
        self.game_state = GameState.RUNNING
        if DEBUG_MAIN_LOOP_LOGS:
            print(f">> Status is {self.game_state}")

    def _close_waiting(self):
        """Cache l'écran d'attente et relance le jeu"""
        self.waiter_node_path.hide()
        self.game_state = GameState.RUNNING
        if DEBUG_MAIN_LOOP_LOGS:
            print(f">> Status is {self.game_state}")
        self.client.game.run()

    def _close_menu_to_main(self):
        """Ferme le menu du pause pour afficher le menu principal (différent si c'est pour retourner au jeu)"""
        for element in self.menu_screen_elements_list:
            element.hide()
        self.death_message.hide()
        self.death_message_distant.hide()
        if self.client and self.client.game and self.client.game.is_running:
            self._disconnect() # disconnect client and server if hosting
        self.game_state = GameState.STOPPED
        if DEBUG_MAIN_LOOP_LOGS:
            print(f">> Status is {self.game_state}")
    
    # ============================
    # Buttons commands part
    # ============================

    def _button_create_new_game(self):
        """Active un server et y connecte le client local déjà existant."""
        if DEBUG_MAIN_LOOP_LOGS:
            print(">> Creating new game...")
        
        self.server = Server(self, self.server_name)
        self.client.set_server_ip('127.0.0.1', as_host=True)
        self._hide_title_and_cursor()
        self._close_main_screen()
        if DEBUG_SHOW_COORDINATES:
            text_node, _ = create_text(self.render2d, 'debug client infos',
                f"Client@{self.server_name} : HOST.", (-0.95, 0, 0.75))
            text_node.setScale(0.04)

    def _button_connect_to_game(self, server_ip):
        """Créé un client qui se connecte automatiquement à une partie existante dont l'ip est donnée."""
        self.client.set_server_ip(server_ip)
        self._hide_title_and_cursor()
        self._close_main_screen()
        if DEBUG_SHOW_COORDINATES:
            text_node, _ = create_text(self.render2d, 'debug client infos',
                f"Client@{self.client.open_servers_dict[(server_ip, 55556)]} : INVITE ({server_ip}).", (-0.95, 0, 0.75))
            text_node.setScale(0.04)
        self.client.game.run()

    def _button_save_game(self):
        """sauvegarde la partie en cours"""
        if DEBUG_MAIN_LOOP_LOGS:
            print(">> Saving progression...")
        with open(SAVE_PATH, "w") as file:
            player_name, player_pos, player_hpr, player_light = self.client.game.get_player_info()
            connected_player_data = self.client.game.get_connected_player_info()
            level = self.client.game.get_level_info()

            file.write(f"{player_name}\n")
            x, y, z = player_pos
            file.write(f"{x},{y},{z}\n")
            h, p, r = player_hpr
            file.write(f"{h},{p},{r}\n")
            file.write(f"{player_light}\n")
            if connected_player_data is None:
                file.write("No connected player.")
            else:
                connected_player_name, connected_player_pos, connected_player_hpr, connected_player_light = connected_player_data
                file.write(f"{connected_player_name}\n")
                cx, cy, cz = connected_player_pos
                file.write(f"{cx}, {cy}, {cz}\n")
                ch, cp, cr = connected_player_hpr
                file.write(f"{ch}, {cp}, {cr}\n")
                file.write(f"{connected_player_light}\n")
                file.write(f"{level}\n")
            file.close()
        if DEBUG_MAIN_LOOP_LOGS:
            print(">> Progression saved.")

    def _button_load_save(self):
        """Créé un nouveau jeu et le met immédiatement à jour avec les informations sauvegardées"""
        if DEBUG_MAIN_LOOP_LOGS:
            print(f">> Loading save at {SAVE_PATH}...")
        self._button_create_new_game()
        with open(SAVE_PATH, "r") as file:
            player_name = file.readline().strip()
            x, y, z = file.readline().strip().split(',')
            h, p, r = file.readline().strip().split(',')
            player_light = file.readline().strip()
            connected_player_name = file.readline().strip()
            if connected_player_name != "No connected player.":
                cx, cy, cz = file.readline().strip().split(',')
                ch, cp, cr = file.readline().strip().split(',')
                connected_player_light = file.readline().strip()
            level = file.readline().strip()
            file.close()

        self.client.game.force_update_player(player_name, (float(x), float(y), float(z)), (float(h), float(p), float(r)), player_light)
        if connected_player_name != "No connected player.":
            self.client.game.force_update_connected_player(connected_player_name, (float(cx), float(cy), float(cz)), (float(ch), float(cp), float(cr)), connected_player_light)
        self.client.game.force_load_level(level)
        
        if DEBUG_MAIN_LOOP_LOGS:
            print(">> Loading done.")

    def _button_refresh_server_list(self):
        """Réactualise la liste des servers disponibles"""
        for button in self.join_servers_buttons_list:
            # button.hide() Might cause a crash when the button actually does not exit.
            button.destroy()
        self.join_servers_buttons_list.clear()
        if DEBUG_MAIN_LOOP_LOGS:
            print(">> refreshing server list...")
        for i, ip_port in enumerate(self.client.open_servers_dict.keys()):
            join_server_button = DirectButton(command=self._button_connect_to_game, extraArgs=(ip_port[0],),
                                              text=(f"{self.client.open_servers_dict[ip_port]}", "Joinning...", f"- Join {self.client.open_servers_dict[ip_port]} -", "error : unaviable"),
                                              scale=0.08,
                                              text_pos=(0, -0.25),
                                              relief=None,
                                              geom=self.buttons_maps.find('**/new_game'),
                                              frameColor=(0, 0, 0, 0.2))
            join_server_button.setPos(-1.35, 0, HIGHER_BUTTON_POS-0.3 - i * 0.2)
            self.join_servers_buttons_list.append(join_server_button)
        
    def _button_quit_game(self):
        """close the game"""
        if DEBUG_MAIN_LOOP_LOGS:
            print(">> Game closed.")
        self.taskMgr.stop()

    def _set_sensitivity(self):
        """change la sensi avec le slider"""
        self.preferences['sensitivity'] = int(self.sensitivity_slider['value'])
        self.sensitivity_text.setText(f"Sensitivity : {self.preferences['sensitivity']}")

    def _set_server_name(self, server_name):
        self.server_name = server_name

    # ============================
    # Running game part
    # ============================

    def _escape_change_menu(self):
        """gère les réactions à la touche escape selon l'état actuel du jeu"""
        if self.game_state == GameState.RUNNING:
            self.game_state = GameState.PAUSED
            if DEBUG_MAIN_LOOP_LOGS:
                print(f">> (ESCAPE) Status is {self.game_state}")
            self.client.game.stop()
            self._show_menu_screen()
            self._show_title_and_cursor()
        elif self.game_state == GameState.PAUSED:
            self._close_menu_screen()
        elif self.game_state == GameState.WAITING:
            if DEBUG_MAIN_LOOP_LOGS:
                print(f">> (ESCAPE) Status is {self.game_state}")
            self.waiter_node_path.hide()
            self._disconnect()
            self._show_main_screen()
        else:
            self._button_quit_game()

    def _hide_title_and_cursor(self):
        window_props = WindowProperties()
        window_props.setCursorHidden(not DEBUG_SHOW_MOUSE)
        self.win.requestProperties(window_props)
        self.title_node_path.hide()

    def _show_title_and_cursor(self):
        window_props = WindowProperties()
        window_props.setCursorHidden(False)
        self.win.requestProperties(window_props)
        self.title_node_path.show()

    def _disconnect(self):
        """Déconnecte proprement le client et le server."""
        if DEBUG_MAIN_LOOP_LOGS:
            print(">> Disconnection...")
        
        if self.server:
            self.server.disconnect_all()
            self.client.disconnect(from_server=True)
            self.server = None
        
        elif self.client:
            self.client.disconnect()

# functions

def main():
    """La fonction principale, point d'entré du programme."""
    game = AllScreens()
    game.run()

