'''
This file contain all functions creating objects, such as light, entities, etc.

Author : Matthew, Romain
Date : 07/12/2025
Python version : 3.12.12
'''

from enum import Enum
from random import randint

# libs de panda3D
from direct.actor.Actor import Actor
from panda3d.core import PointLight, PerspectiveLens, Spotlight, AmbientLight, DirectionalLight, Vec3, Point3

# Nos fichiers
from src.constants import *
from src.utilities import dist_A_B

# Classes

class EntityType(Enum):
    CYBORG = 2
    ALIEN = 1
    PNJ = 0

class Entity:
    '''
    Créé une entitée
    '''
    def __init__(self, name:EntityType, model, pos, rotation, scale=(1, 1, 1)):
        self.name = name
        self.actor = Actor(model)
        self.actor.setPosHprScale(Vec3(pos), Vec3(rotation), Vec3(scale))
        self.vertical_speed = 0

    def update(self, pos, rotation):
        """met à jour la position et l'orientation de l'entity"""
        self.actor.setPos(pos)
        self.actor.setHpr(rotation)

    def getHpr(self) -> tuple[float, float, float]:
        return self.actor.getHpr()

    def getPos(self) -> tuple[float, float, float]:
        return self.actor.getPos()

    def destroy(self):
        """fait disparaitre l'entity"""
        self.actor.hide()
        self.actor.cleanup()


class Player(Entity):
    def __init__(self, name:EntityType, pos=(0,0,0), rotation=(0,0,0), Scale=(1, 1, 1)):
        model = PATH_TO_CYBORG if name == EntityType.CYBORG else PATH_TO_ALIEN
        super().__init__(name, model, pos, rotation, Scale)
        self._set_cameraman()
        self.vision_light = createNewLight(
            light_type='Spotlight', light_name='visionLight', source=self.cameraman,
            color=(1,1,1), intensity=100, attenuation=(0,1,0), pos=(0, 0, 0)
        )
        self.power_light = False

    def _set_cameraman(self):
        self.cameraman = Actor('models/misc/sphere')
        self.cameraman.reparentTo(self.actor)
        self.cameraman.setPos(1, 1, 1)
        self.cameraman.hide()


class PNJ(Entity):
    def __init__(self, name:EntityType, area:tuple[tuple[int],tuple[int]], pos=(0,0,0), rotation=(0,0,0), Scale=1, speed = 3):
        super().__init__(name, PATH_TO_PNJ, pos, rotation, Scale)
        self.speed = speed
        self.living_space = area
        self.choose_dest()
        self.wait = randint(10,500)

    def update(self, dt):
        if dist_A_B(self.actor.getPos(), self.objectif) <= self.speed*dt:
            if self.wait > 0:
                self.wait -= 1
            else :
                self.actor.setPos(self.objectif)
                self.choose_dest()
                self.wait = randint(10,500)
        else :
            self.AI_journey(dt)

    def AI_journey(self, dt):
        self.actor.lookAt(self.objectif)
        self.actor.setPos(self.actor.getPos() + self.actor.getQuat().getForward() * self.speed * dt)

    def choose_dest(self):
        assert (self.living_space[0][0] < self.living_space[1][0], 'PNJ:choose_dest -> cordonné a l IA fausse, X départ < X arrivé')
        assert (self.living_space[0][1] < self.living_space[1][1], 'PNJ:choose_dest -> cordonné a l IA fausse, Y départ < Y arrivé')
        assert (self.living_space[0][2] == self.living_space[1][2], 'PNJ:choose_dest -> cordonné a l IA fausse, pas un plan en 2D sur les Z')
        # print("self.living_space[0][0] : ", self.living_space[0][0], " self.living_space[1][0] : ", self.living_space[1][0])
        # print("self.living_space[0][1] : ", self.living_space[0][1], " self.living_space[1][1] : ", self.living_space[1][1])
        # print("self.living_space[0][2] : ", self.living_space[0][2], " self.living_space[1][2] : ", self.living_space[1][2])
        # print("       ") # ROMAIN EFFACE TES PRINTS AVANT DE PUSH SUR DEVELOP !
        self.objectif = (randint(self.living_space[0][0], self.living_space[1][0]),
                        randint(self.living_space[0][1], self.living_space[1][1]),
                        self.living_space[0][2])


class ForceField:
    '''
    Un champ de force, qui tourne sur lui même, part d'un point et se répète un nombre donné de fois.
    Peu être actif ou non, porter dans un sens ou dans l'autre, et possède une orientation modifiable.
    Lorsqu'une entité entre en collision avec un champ de force, elle est déplacée dans le sens du champ.
    Les noms des fonctions liées à l'activation doivent être consistants avec ceux des champs de force,
    car ces deux classes peuvent être contrôlées par des panneaux avec la même logique.
    '''
    # TODO : sub forcefield actors positioning can be simplified by reparenting them to the main actor
    def __init__(self, name, pos, lenght, hpr):
        x, y, z = pos
        self.main_actor = Actor(PATH_TO_FORCEFIELD)
        self.lenght = lenght

        self.main_actor.setName(name)
        self.main_actor.setScale(0.6, 0.6, 0.6)
        self.main_actor.setPos(pos)
        self.main_actor.setHpr(hpr)
        self.main_actor.hide()

        self.sub_actors_list:list[Actor] = []
        for i in range(lenght):
            sub_actor = Actor(PATH_TO_FORCEFIELD)
            sub_actor.setName(f"{self.main_actor.getName()}_child_{i}")
            sub_actor.setScale(1, 1, 1)
            x, y, z = pos
            vx, vy, vz = self.main_actor.getQuat().getForward()
            sub_actor.setPos(x + FORCEFIELD_MODEL_LEN * i * vx, y + FORCEFIELD_MODEL_LEN * i * vy, z + FORCEFIELD_MODEL_LEN * i * vz)
            sub_actor.setHpr(hpr)
            sub_actor.hide()
            self.sub_actors_list.append(sub_actor)

        self.push = FORCEFIELD_PUSH
        self.active = False  # This check if the forcefield is just activated by the INVITE Alien client, requesting true activation
        self.is_open = False # this check if the forcefield is indeed activated, visible and efficient
        self.can_be_activated = False 
        
        if DEBUG_ACTIVATE_FORCEFIELDS:
            self.active = True
            self.open()

    def enable_activation(self):
        """Autorise l'activation du champ de force"""
        self.can_be_activated = True

    def disable_activation(self):
        """Interdit l'activation du champ de force"""
        self.can_be_activated = False

    def is_activable(self):
        return self.can_be_activated

    def activate(self, active=True):
        """Active ou désactive le champ de force. C'est uniquement l'interaction de l'Alien du client INVITE."""
        self.active = active

    def open(self):
        """Méthode nécessaire pour la consistance avec les portes. Elle active rééllement le champ de force."""
        self.is_open = True
        self.main_actor.show()
        for actor in self.sub_actors_list:
            actor.show()
        if DEBUG_MAIN_LOOP_LOGS:
            print(f"** {self.main_actor.getName()} opened.")

    def barrel_roll(self):
        """make the forcefield roll around its rolling axe"""
        if self.is_open:
            h, p, r = self.main_actor.getHpr()
            self.main_actor.setHpr(h, p, r+0.25)
            for actor in self.sub_actors_list:
                actor.setHpr(h, p, r+0.25)
    
    def getHpr(self) -> tuple[float, float, float]:
        return self.main_actor.getHpr()
    
    def getPos(self) -> tuple[float, float, float]:
        return self.main_actor.getPos()
    
    def getForwardVector(self):
        return self.main_actor.getQuat().getForward()
    
    def rotateTo(self, h, p):
        """Donne au champ de force une nouvelle rotation."""
        self.main_actor.setH(h)
        self.main_actor.setP(p)
        for i, actor in enumerate(self.sub_actors_list):
            x, y, z = self.main_actor.getPos()
            vx, vy, vz = self.main_actor.getQuat().getForward()
            actor.setPos(x + FORCEFIELD_MODEL_LEN * i * vx, y + FORCEFIELD_MODEL_LEN * i * vy, z + FORCEFIELD_MODEL_LEN * i * vz)
            actor.setH(h)
            actor.setP(p)


class Panel:
    '''
    Panneau de contrôle de type Cyborg ou Alien.
    L'attribut actor est l'image du panneau dans le jeu
    L'attribut control est l'élément contrôlé par l'interaction.
    '''
    def __init__(self, name, linked_character:EntityType, control, pos, hpr=(0, 0, 0)):
        model = PATH_TO_CYBORG_INTERACTION_PANEL if linked_character == EntityType.CYBORG else PATH_TO_ALIEN_INTERACTION_PANEL
        self.actor = Actor(model)
        self.actor.setPos(pos)
        self.actor.setHpr(hpr)
        self.actor.setName(name)
        self.control = control
        self.linked_character = linked_character


class DoorType(Enum):
    LEGERE = 1
    LOURDE = 2


class Door:
    '''
    Porte de type Lourde ou Légère.
    Les noms des fonctions liées à l'activation doivent être consistants avec ceux des champs de force,
    car ces deux classes peuvent être contrôlées par des panneaux avec la même logique.
    '''
    def __init__(self, door_type:DoorType, pos, hpr=(0, 0, 0)):
        model = PATH_TO_PORTE_LEGERE if door_type == DoorType.LEGERE else PATH_TO_PORTE_LOURDE
        self.actor = Actor(model)
        self.actor.setPos(pos)
        self.actor.setHpr(hpr)
        self.type = door_type
        self.can_be_activated = False
        self.activated_on_our_side = False
        self.activated_at_distant = False # si la porte a été activée par l'autre client
        self.is_open = False

        if DEBUG_OPEN_ALL_DOORS:
            self.activated_on_our_side = True
            self.open()

    def enable_activation(self):
        """Indique qu'un joueur est à porté et peut ouvrir la porte en pressant la touche d'interaction."""
        self.can_be_activated = True

    def disable_activation(self):
        """Indique qu'aucun joueur n'est à porté."""
        self.can_be_activated = False

    def is_activable(self):
        """Vérifie si suffisament de joueurs tentent d'ouvrir la porte"""
        return self.can_be_activated

    def activate(self, active=True):
        """Indique si la porte a été ouverte de ce côté. En attente des données de HOST pour l'ouvrir effectivement."""
        if active and self.is_activable():
            self.activated_on_our_side = True
            if DEBUG_MAIN_LOOP_LOGS:
                print(f"** {self.type} activated.")
    
    def open(self):
        if self.type == DoorType.LEGERE and (self.activated_at_distant or self.activated_on_our_side) or \
            self.type == DoorType.LOURDE and self.activated_at_distant and self.activated_on_our_side:
            self.force_open()

    def force_open(self):
        """Méthode de débug permettant d'ouvrir la porte même si c'est une porte lourde n'étant pas activée des deux côtés"""
        if not self.is_open:
            self.actor.setZ(self.actor.getZ() + 2.5)
            self.is_open = True
            if DEBUG_MAIN_LOOP_LOGS:
                print(f"** {self.type} opened.")
    
    def close(self):
        if self.is_open:
            self.actor.setZ(self.actor.getZ() - 2.5)
            self.is_open = False
    
    def getHpr(self) -> tuple[float, float, float]:
        return self.actor.getHpr()
    
    def getPos(self) -> tuple[float, float, float]:
        return self.actor.getPos()

# Functions

def createNewLight(light_type, source, light_name, pos=(0, 0, 0), attenuation=(1, 0, 1), color=(1, 1, 1), intensity=1, direction=(0, 0, 0)):
    """
    create a light of the given type attached to the given source
    
    Optionnal inputs
    ----------------
    light_type (str) : the type of the light among PointLight, AmbientLight, SpotLight.
    source (Node) : the panda3D's object to which the light is bound.
    light_name (str) : the name of the light node.
    pos (tuple[float]) : position of the light. (0, 0, 0) on default
    attenuation (tuple[float]) : manage how the light gradually fade of with distance. (1, 0, 1) on default.
        Refer to https://docs.panda3d.org/1.10/python/programming/render-attributes/lighting for more informations.
    color (tuple[float]) : set a rgb color to the light. (1, 1, 1) on default. 
    intensity (float) : how powerful the light is. 1 on default.
    direction (tuple[float]) : if the light has a direction, define it.
    """
    if light_type == 'Spotlight':
        light = Spotlight(light_name)
        lens = PerspectiveLens()
        light.setLens(lens)

    elif light_type == 'AmbientLight':
        light = AmbientLight(light_name)

    elif light_type == 'PointLight':
        light = PointLight(light_name)

    elif light_type == 'DirectionalLight':
        light = DirectionalLight(light_name)
        light.setDirection(Vec3(direction))
        
    else:
        raise ValueError("Invalid light_type.")

    r, g, b = color
    light.setColor((r*intensity, g*intensity, b*intensity, 1))

    if light_type != 'AmbientLight' and light_type != 'DirectionalLight': # ambient light has no attenuation, as it comes from everywhere
        light.attenuation = attenuation

    light = source.attachNewNode(light)
    x, y, z = pos
    light.setPos(x, y, z)
    return light
