# With all our Forces

> [Cyborg], elle-même à moitié changée en robot, travaillait sur ses bien-aîmées machines dans la salle des moteurs du Speartech II, un croiseur de la Flotte Interstellaire. L'humanité en est à ses débuts dans le voyage interstellaire et explore ses nouveaux horizons.
> Soudain, sonnerie d'alerte, choc soudain, puis un calme de mort... Une navette d'un design inconnu vient de percuter le vaisseau, justement au niveau des moteurs. Son étrange passager tente d'établir une communication entre-eux. La journée s'annonce peu ordinaire.

## Gameplay

Piégés dans l'épave d'un croiseur interstellaire, [Cyborg] et [Alien] doivent trouver un échappatoire à l'aide de leurs pouvoirs asymétriques. A travers une dizaine de salles, Ils devront activer des champs de force et modifier leurs placements pour contourner de nombreux obstacles et échapper aux poursuivant du mystérieux alien. Alliez analyse et communication pour résoudre à deux la situation de vos personnages. Seul [Cyborg] peut modifier les champs de force, et seul [Alien] peut se servir d'eux pour se déplacer. Il faudra bien s'accrocher.

## Sommaire

- Installation
- Lancer le jeu
- Jouer
- Rejoindre l'équipe de playtest
- Crédits

## Installation
With all our Forces n'a pas encore d'installeur prêt à être utilisé. Le jeu tourne sur python 3.12+ avec la librairie Panda3D.

#### Télécharger l'archive :
Téléchargez l'archive de la dernière option disponible, puis décompressez-la dans un dossier de votre choix.

#### Installer Python :
Rendez-vous sur le [site officiel de Python](https://www.python.org/downloads/)
et choisissez votre méthode d'installation pour une version stable de python 3.12+.

#### Installer Panda3D :
Dans le dossier moonshard-project obtenu après avoir décompressé l'archive, créez un .venv avec la commande suivante :
```bash
python3 -m venv <nom-du-venv>
```
Activez-le avec la commande suivante si votre terminal est bash :
```bash
source <nom-du-venv>/bin/activate
```
Si vous utilisez un autre terminal, référez-vous à la [documentation python](https://docs.panda3d.org/1.10/python/introduction/index).  

Enfin, installez la version la plus récente de Panda3D avec la commande suivante :
```bash
pip install panda3d
```
Si vous avez des soucis avec cette étape, rendez-vous sur la [documentation officielle de Panda3d](https://docs.panda3d.org/1.10/python/introduction/index).

## Lancer le jeu
Double-cliquez sur le fichier 'With All Our Forces'.
Pour ouvrir un serveur sur votre LAN, remplissez la barre de texte 'nom du serveur' puis cliquez simplement sur 'Nouveau jeu'.  
Pour rejoindre un serveur existant sur votre LAN, rafraîchissez la liste des serveurs jusqu'à voir apparaître le bon serveur, puis cliquez dessus.

Le jeu ne peut pas tourner tant que deux joueurs ne sont pas connectés.

## Jouer
### Principe
Vous et votre camarade contrôlez chacun un personnage différent. Le joueur qui a ouvert le serveur contrôle la Cyborg, tandis que le second contrôle l'Alien.
Pour gagnez, vous devez sortir des différentes salles du vaisseau sinistré.
La Cyborg peut modifier la direction des champs de force, leur puissance ainsi que les portes du vaisseau.
L'Alien peut activer les champs de force et se déplacer grâce à eux.
Vos deux personnages peuvent se tenir afin de traverser certains obstacles ensemble.

### Contrôles
- Sur un clavier AZERTY :
  - `Z` : Avancer  
  - `S` : Reculer  
  - `Q` : Latéral gauche  
  - `D` : Latéral droit  
  - `E` : Interagir avec les objets  
  - `A` : Allumer/éteindre la lumière
- Ces contrôles s'adaptent à votre clavier. Utilisez les même emplacements de touches pour un clavier QWERTY.
