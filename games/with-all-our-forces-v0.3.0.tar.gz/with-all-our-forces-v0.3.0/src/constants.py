'''
This file contain all constant parameters of the game.

Author : Matthew
Date : 07/12/2025
Python version : 3.12.12
'''

# Debugging ---------------------------------------------------------------------------------------------------------------------------
ADMIN_SESSION = False                                           # Active la plupart des options de debug
EASY_SESSION = False                                            # Active une session qui ouvre toutes les portes et active tous les champs de force
LOGS_SESSION = ADMIN_SESSION or False                           # Affiche tous les logs d'execution
LOCAL_TEST = False                                              # Permet le lancement de plusieurs jeux sur la même machine. /!\ le CLIENT *DOIT* être sur 55555.
DEBUG_MAIN_LOOP_LOGS = LOGS_SESSION or False                    # Affiche en console les informations d'execution de la boucle principale
DEBUG_NETWORK_LOGS = LOGS_SESSION or False                      # Affiche en console les informations réseau majeures
DEBUG_NETWORK_ALL_LOGS = DEBUG_NETWORK_LOGS and False           # Affiche en console toutes les logs de transfères de données
DEBUG_GAME_LOGS = LOGS_SESSION or False                         # Affiche en console les logs majeures d'execution du jeu
DEBUG_PLAYERS_LOGS = LOGS_SESSION or False                      # Affiche en console les logs majeures relatives aux deux joueurs
DEBUG_PLAYERS_ALL_LOGS = DEBUG_PLAYERS_LOGS and False           # Affiche en console toutes les logs relatives aux joueurs y compris la mise à jour de leurs positions
DEBUG_SHOW_COORDINATES = ADMIN_SESSION or False                 # Affiche à l'écran du jeu les coordonnées actuelles du joueur
DEBUG_FREE_CAMERA = ADMIN_SESSION or False                      # Détache la caméra du joueur, permettant de voler et traverser les murs
DEBUG_SHOW_MOUSE = LOCAL_TEST or False                          # Affiche la souris
DEBUG_FREE_MOUSE = LOCAL_TEST or False                          # Permet a la souris de quitter la fenêtre de jeu
DEBUG_DISABLE_FULLSCREEN = LOCAL_TEST or False                  # Désactive le plein écran
DEBUG_SHOW_COLLIDERS = ADMIN_SESSION or False                   # Affiche les boîtes de collisions
DEBUG_DISABLE_GRAVITY = ADMIN_SESSION or False                  # Désactive la gravité
DEBUG_OPEN_ALL_DOORS = EASY_SESSION or False                    # Fait disparaître toutes les portes
DEBUG_ACTIVATE_FORCEFIELDS = EASY_SESSION or False              # Active tous les champs de force par défaut
DEBUG_DISABLE_AI_KILL = EASY_SESSION or ADMIN_SESSION or False  # Désactive la capacité des pnj à bloquer le jeu lorsqu'un joueur est pris     

# Game -------------------------------------------------------------------------------------------------------------------------------
# Controls
FORWARD_CONTROL = 'z'                               # Touche pour avancer
BACKWARD_CONTROL = 's'                              # Touche pour reculer
RIGHT_CONTROL = 'd'                                 # Touche pour aller à droite
LEFT_CONTROL = 'q'                                  # Touche pour aller à gauche
INTERACT_CONTROL = 'e'                              # Touche permettant au joueur d'interagir avec les panneaux
GRAB_CONTROL = 'f'                                  # Touche permettant au joueur d'attraper l'autre
THROW_CONTROL = 'mouse1'                            # Touche permettant au joueur de jeter l'autre en hauteur

# Networking
CLIENT_PORT = 55555                                 # Le port utilisé par le client. Le port du server est CLIENT_PORT + 1
LAN_ADDRESS = '192.168.1.255'                       # Adresse de la LAN. 192.168.1.255 est le réseau privé habituel.
SERVER_DISCONNECT_MESSAGE = 'SHUTING DOWN'          # Demande de déconnexion envoyée par le server
CLIENT_DISCONNECT_MESSAGE = 'DISCONNECTED'          # Information de déconnexion envoyée par le client
PLAYER_DATA_MESSAGE = 'PLAYER DATA'                 # Flag du paquet contenant toutes les infos du joueur
LEVEL_DATA_MESSAGE = 'LEVEL DATA'                   # Flag du paquet contenant toutes les infos du niveau
ACTIVATIONS_DATA_MESSAGE = 'ACTIVATION DATA'        # Flag du paquet contenant touts les états d'activation des portes et champs de force
SERVER_ALIVE_MESSAGE = 'WAITING PLAYER'             # Information de place libre sur un server
CLIENT_GREET_MESSAGE = 'GREETING'                   # Information de connection d'un client à un server
CLIENT_GAME_STATE_MESSAGE = 'GAME STATE'            # Information d'états du jeu (running, dead, crash)

# Graphics
GAME_NAME = "With All Our Forces"                   # Titre du jeu
HIGHER_BUTTON_POS = 0.3                             # Hauteur en Z des boutons les plus hauts

# Physics
CHARACTER_SPEED = 6                                 # Vitesse de marche des personnage
CHARACTER_JUMP_SPEED = 4                            # Vitesse de saut des personnages (modifie la hauteur de saut en fonction de la gravité)
GRAVITY =  9.81                                     # Constante de gravité du jeu
DEADLY_DEPTH = -3.5                                 # Hauteur négative à laquelle les joueur sont tués
FORCEFIELD_PUSH = 0.3                               # Force appliquée par le champ de force aux joueurs
FORCEFIELD_GRAVITY = 0                              # Annulation de la gravité dans les champs de force
FORCEFIELD_ROTATION_SPEED = 1                       # Vitesse de rotation des champs de force lorsque contrôlés par un panneau de rotation
DEBUG_CAMERA_SPEED = 3                              # Vitesse de la caméra détachée
GRAB_DIST = 0.6                                     # Distance à laquelle un personnage tiens l'autre lorsqu'il l'attrape.
THROW_DIST = 3                                      # Hauteur à laquelle un personne peut envoyer l'autre.

# AI Behaviour
AI_DETECTION_RANGE = 20                             # Distance à laquelle les pnj poursuivent les joueurs
AI_KILL_RANGE = 1.5                                 # Distance à laquelle les pnj tuent les joueurs (et arrêtent la partie)
AI_SPEED = CHARACTER_SPEED - 1                      # Vitesse de déplacement des pnj

# Others
FORCEFIELD_MODEL_LEN = 7.5                          # Longueur d'un modèle de champ de force
SPAWN_CYBORG = (0, 0, 1.5)                          # Position d'apparition de la Cyborg
SPAWN_ALIEN = (0, -10, 1.5)                         # Position d'apparition de l'Alien

# Files --------------------------------------------------------------------------------------------------------------------------------
# Rooms
PATH_TO_ROOM1 = "assets/specific/room/salle1.bam"
PATH_TO_ROOM2 = 'assets/specific/room/salle2.bam'
PATH_TO_ROOM3 = 'assets/specific/room/salle3.bam'
PATH_TO_ROOM4 = 'assets/specific/room/salle4.bam'
PATH_TO_ROOM5 = 'assets/specific/room/salle5.bam'
PATH_TO_SAS = 'assets/bases/room/Sas.bam'



# Objects
PATH_TO_CYBORG_INTERACTION_PANEL = 'assets/bases/object/Cyborg_Interaction_Panel.bam'
PATH_TO_ALIEN_INTERACTION_PANEL = 'assets/bases/object/Alien_Interaction_Panel.bam'
PATH_TO_FORCEFIELD = 'assets/bases/object/forcefield_lines.bam'
PATH_TO_GENERATOR = 'assets/bases/object/ForceField_Generator.bam'
PATH_TO_PORTE_LEGERE = 'assets/bases/object/Porte_Legere.bam'
PATH_TO_PORTE_LOURDE = 'assets/bases/object/Porte_Lourde.bam'

# Characters
PATH_TO_CYBORG = 'assets/character/cyborg.bam'
PATH_TO_ALIEN = 'assets/character/alien.bam'
PATH_TO_PNJ = 'assets/character/pnj.bam'

# UI elements
PATH_TO_BUTTON = 'assets/button_maps'

# Fonts
YRSA_SEMIBOLD = 'assets/fonts/Yrsa-SemiBold.ttf'
PATH_TO_BACKGROUND_IMAGE = 'assets/UI_elements/background_menu.png'
PATH_TO_TITLE_IMAGE = 'assets/UI_elements/title.png'

# System
SAVE_PATH = "saves/latest_save.txt"
