'''
Fichier contenant des fonctions pour des calculs génériques.

Author : Matthew, Romain
Date : 16/03/2026
Python version : 3.12.12
'''

from enum import Enum

from panda3d.core import TextNode, Vec3, KeyboardButton
from math import sqrt

# Enums

class Axis(Enum):
    """
    A représente un axe par rapport à un nœud parent concerné,
    avec X l'avant, Y la hauteur, et Z la droite.
    - A : l'axe (X, Y ou Z)
    - IA : l'inverse de l'axe, égal à -A (IX, IY ou IZ)
    """
    X = 0
    IX = 1
    Y = 2
    IY = 3
    Z = 4
    IZ = 5

class Rotation(Enum):
    """
    A représente un axe de rotation par rapport à un nœud parent concerné,
    avec H le heading (direction par rapport au sol), P le pitch (direction par rapport à la hauteur), et R le roll (tour sur lui-même).
    - A : l'axe de rotation (H, P, R)
    - IA : l'inverse de l'axe, égal à -A (IH, IP, IR)
    """
    H = 0
    IH = 1
    P = 2
    IP = 3
    R = 4
    IR = 5

# functions

def is_in_area(start_pos:tuple[float, float, float], end_pos:tuple[float, float, float], target) -> bool:
        """
        Vérifie qu'une target donnée est dans une zone comprise entre start_pos et end_pos
        
        start_pos, end_pos (tuple[float, float, float]) : respectivement les points de début et de fin d'un cube
        target (NodePath) : l'objet dont la position sera testée
        """
        start_x, start_y, start_z = start_pos
        end_x, end_y, end_z = end_pos
        assert start_x <= end_x, "start_x superieur à end_x"
        assert start_y <= end_y, "start_y superieur à end_y"
        assert start_z <= end_z, "start_z superieur à end_z"
        return (start_x <= target.getX() <= end_x) and (start_y <= target.getY() <= end_y) and (start_z <= target.getZ() <= end_z)


def dist_A_B(A:tuple[int, int, int], B:tuple[int, int, int]):
    return sqrt((A[0] - B[0]) * (A[0] - B[0]) + (A[1] - B[1]) * (A[1] - B[1]) + (A[2] - B[2]) * (A[2] - B[2])) # sqrt (x_{B} - x_{A})^2 + (y_{B} - y_{A})^2) et aussi pour les Z

def create_text(parent, name:str, text:str, pos:tuple[int, int, int]):
    """
    Créé un texte à la position donnée et l'affiche. Retourne le nœud chemin vers le texte et le nœud du texte.

    parent (NodePath) : où attacher le noeud du texte (habituellement render2d)
    name (str) : le nom du nodepath
    text (str) : le texte affiché
    pos (tuple[int, int, int]) : la position du texte sur l'écran
    """
    title_text = TextNode(name)
    title_text.setText(text)
    title_text.setSmallCaps(True)
    textNodePath = parent.attachNewNode(title_text)
    textNodePath.setScale(0.08)
    textNodePath.setPos(pos)
    return textNodePath, title_text

def Smooth_operator(obj, end , dt, speed = 1):
    uni = Vec3(end[0] - obj.getX(), end[1] - obj.getY(), end[2] - obj.getZ())
    uni.normalized()
    obj.setPos(obj.getPos() + uni*speed*dt)

# Macros

is_pressed_ascii = lambda key : base.mouseWatcherNode.is_button_down(KeyboardButton.ascii_key(key)) #type: ignore
is_pressed_space = lambda : base.mouseWatcherNode.is_button_down(KeyboardButton.space()) #type: ignore
is_pressed_shift = lambda : base.mouseWatcherNode.is_button_down(KeyboardButton.shift()) #type: ignore
# Usign the "expected" way of accessing base from panda3d. This is ugly, but I wanted a clean macro
