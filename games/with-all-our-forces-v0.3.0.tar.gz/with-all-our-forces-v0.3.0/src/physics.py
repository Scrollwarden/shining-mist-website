"""
The file handle all physics of the game. J'en parlerai a Ollie des fautes d'anglais

Author : Ninon Allier, Noé Bavière
Date : 11/01/2026
Python version : 3.9
"""

from panda3d.core import Point3
from panda3d.core import BitMask32, CollisionRay, CollisionNode, CollisionBox, CollisionSphere

def setCollidebox(node, size, bit):
    """
    Ajoute une boîte de collision
    
    node (NodePath) : L'objet qui reçoit une collidbox
    size (tuple[int]) : Taille de la collidbox en (x, y, z)
    bit (int) : le bit de collisions (deux nœuds de collisions sur un bitmask différents ne se détectent pas)
    """
    cnode = CollisionNode(f"{node.getName()}_collider")
    half_x, half_y, half_z = size
    cnode.addSolid(CollisionBox(Point3(0,0,half_z), half_x, half_y, half_z))
    cnode.setIntoCollideMask(BitMask32.bit(bit))
    return node.attachNewNode(cnode)

def setGroundCollisionRay(node):
    """Crée et retourne un rayon vertical utilisé pour détecter le sol sous le joueur."""
    ground_ray = CollisionRay()
    ground_ray.setOrigin(0, 0, 1.5)
    ground_ray.setDirection(0, 0, -1)

    cnode = CollisionNode('groundRay')
    cnode.addSolid(ground_ray)
    cnode.setFromCollideMask(BitMask32.bit(0))
    cnode.setIntoCollideMask(BitMask32.allOff())
    return node.attachNewNode(cnode)

def set_interaction_zone(node, radius, bit):
    """
    Créé une zone d'interaction sous forme d'une sphère centrée autour du nœud.
    
    node (NodePath) : l'objet sur lequel la zone d'interaction est associée.
    radius (float) : le rayon de la sphère
    bit (int) : le bitmask de collision
    """
    cnode = CollisionNode(node.getName())
    cnode.addSolid(CollisionSphere(0, 0, 0.85, radius))
    cnode.setFromCollideMask(BitMask32.allOff())
    cnode.setIntoCollideMask(BitMask32.bit(bit))

    return node.attachNewNode(cnode)

def set_interaction_capsule(node, parent, size, bit):
    """
    Créé une zone d'interaction sous forme d'une capsule autour du noeud donné.
    
    node (NodePath) : l'objet sur lequel la zone d'interaction est associée.
    size (float) : la longueur de la capsule
    bit (int) : le bitmask de collision
    this function need the parent of the node in order to create the capsule with the correct orientation
    """
    cnode = CollisionNode(node.getName())
    x, y, z = node.getPos()
    vx, vy, vz = node.getQuat().getForward()
    # This CollisionBox uses the point-to-point implementation instead of the center-to-point
    cnode.addSolid(CollisionBox(Point3(x -0.6, y -0.6, z -0.6), Point3(x + 0.6 + size * vx, y + 0.6 + size * vy, z + 0.6 + size * vz)))
    cnode.setFromCollideMask(BitMask32.allOff())
    cnode.setIntoCollideMask(BitMask32.bit(bit))
    return parent.attachNewNode(cnode)
