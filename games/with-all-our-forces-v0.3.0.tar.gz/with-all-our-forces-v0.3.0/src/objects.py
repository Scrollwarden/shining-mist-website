'''
This file contain all functions creating objects, such as light, entities, etc.

Author : Matthew, Romain
Date : 07/12/2025
Python version : 3.12.12
'''

from enum import Enum
from random import uniform, randint

# libs de panda3D
from direct.actor.Actor import Actor
from panda3d.core import PointLight, PerspectiveLens, Spotlight, AmbientLight, DirectionalLight, Vec3

# Nos fichiers
from src.constants import *
from src.utilities import dist_A_B, Rotation

# Classes

class EntityType(Enum):
    CYBORG = 2
    ALIEN = 1
    PNJ = 0

class Entity:
    '''
    Créé une entitée
    '''
    def __init__(self, name:EntityType, model, pos, rotation, scale):
        self.name = name
        self.actor = Actor(model)
        self.actor.setPosHpr(Vec3(pos), Vec3(rotation))
        self.actor.setScale(scale)
        self.vertical_speed = 0

    def update(self, pos, rotation):
        """met à jour la position et l'orientation de l'entity"""
        self.actor.setPos(pos)
        self.actor.setHpr(rotation)

    def getHpr(self) -> tuple[float, float, float]:
        return self.actor.getHpr()

    def getPos(self) -> tuple[float, float, float]:
        return self.actor.getPos()

    def destroy(self):
        """fait disparaitre l'entity"""
        self.actor.hide()
        self.actor.cleanup()


class Player(Entity):
    '''
    Entités représentatives des joueurs (local et connecté).
    '''
    def __init__(self, name:EntityType, pos=(0,0,0), rotation=(0,0,0), scale=0.5):
        model = PATH_TO_CYBORG if name == EntityType.CYBORG else PATH_TO_ALIEN
        super().__init__(name, model, pos, rotation, scale)
        self._set_cameraman()
        self.vision_light = createNewLight(
            light_type=LightType.SPOT, light_name='visionLight', source=self.cameraman,
            color=(1,1,1), intensity=100, attenuation=(0,1,0), pos=(0, 0, 0)
        )
        self.power_light = False
        self.can_grab = False
        self.is_grabbing = False
        self.is_throwing = False

    def _set_cameraman(self):
        self.cameraman = Actor('models/misc/sphere')
        self.cameraman.reparentTo(self.actor)
        self.cameraman.setPos(1, 1, 1)
        self.cameraman.hide()


class PNJ(Entity):
    '''
    Entité représentative des personnages Non joueurs contrôlés en local sur le client HOST.
    Leur hauteur de déplacement est définit dans l'attribut living_space, qui est prioritaire sur celle d'apparition.
    '''
    def __init__(self, area:tuple[tuple[int],tuple[int]], pos=(0,0,0), rotation=(0,0,0), scale=0.5):
        super().__init__(EntityType.PNJ, PATH_TO_PNJ, pos, rotation, scale)
        self.living_space = area
        self.choose_dest()
        self.wait = randint(10,500)

    def update(self, dt):
        if dist_A_B(self.actor.getPos(), self.objectif) <= AI_SPEED * dt:
            if self.wait > 0:
                self.wait -= 1
            else :
                self.actor.setPos(self.objectif)
                self.choose_dest()
                self.wait = randint(10,500)
        else :
            self.AI_journey(dt)

    def AI_journey(self, dt):
        self.actor.lookAt(self.objectif)
        self.actor.setPos(self.actor.getPos() + self.actor.getQuat().getForward() * AI_SPEED  * dt)

    def choose_dest(self):
        assert self.living_space[0][0] < self.living_space[1][0], 'PNJ:choose_dest -> cordonné a l IA fausse, X départ < X arrivé'
        assert self.living_space[0][1] < self.living_space[1][1], 'PNJ:choose_dest -> cordonné a l IA fausse, Y départ < Y arrivé'
        assert self.living_space[0][2] == self.living_space[1][2], 'PNJ:choose_dest -> cordonné a l IA fausse, pas un plan en 2D sur les Z'
        self.objectif = (uniform(self.living_space[0][0], self.living_space[1][0]),
                        uniform(self.living_space[0][1], self.living_space[1][1]),
                        self.living_space[0][2])


class ForceField:
    '''
    Un champ de force, qui tourne sur lui même, part d'un point et se répète un nombre donné de fois.
    Peu être actif ou non, porter dans un sens ou dans l'autre, et possède une orientation modifiable.
    Lorsqu'une entité entre en collision avec un champ de force, elle est déplacée dans le sens du champ.
    Les noms des fonctions liées à l'activation doivent être consistants avec ceux des champs de force,
    car ces deux classes peuvent être contrôlées par des panneaux avec la même logique.
    '''
    def __init__(self, name, pos, lenght, hpr):
        self.main_actor = Actor(PATH_TO_FORCEFIELD)
        self.lenght = lenght

        self.main_actor.setName(name)
        self.main_actor.setScale(0.8, 0.8, 0.8)
        self.main_actor.setPos(pos)
        self.main_actor.setHpr(hpr)
        self.main_actor.hide()

        self.sub_actors_list:list[Actor] = []
        for i in range(lenght):
            sub_actor = Actor(PATH_TO_FORCEFIELD)
            sub_actor.setName(f"{self.main_actor.getName()}_child_{i}")
            sub_actor.setScale(0.8, 0.8, 0.8)
            sub_actor.reparentTo(self.main_actor)
            sub_actor.setPos(0, FORCEFIELD_MODEL_LEN * (i+1), 0)
            sub_actor.hide()
            self.sub_actors_list.append(sub_actor)

        self.push = FORCEFIELD_PUSH
        self.active = False  # This check if the forcefield is just activated by the INVITE Alien client, requesting true activation
        self.is_open = False # this check if the forcefield is indeed activated, visible and efficient
        self.can_be_activated = False 
        
        if DEBUG_ACTIVATE_FORCEFIELDS:
            self.active = True
            self.open()

    def enable_activation(self):
        """Autorise l'activation du champ de force"""
        self.can_be_activated = True

    def disable_activation(self):
        """Interdit l'activation du champ de force"""
        self.can_be_activated = False

    def is_activable(self):
        return self.can_be_activated

    def activate(self, active=True):
        """Active ou désactive le champ de force. C'est uniquement l'interaction de l'Alien du client INVITE."""
        self.active = active

    def is_active(self):
        return self.active

    def open(self):
        """Méthode nécessaire pour la consistance avec les portes. Elle active rééllement le champ de force."""
        self.is_open = True
        self.main_actor.show()
        for actor in self.sub_actors_list:
            actor.show()
        if DEBUG_MAIN_LOOP_LOGS:
            print(f"** {self.main_actor.getName()} opened.")
    
    def getHpr(self) -> tuple[float, float, float]:
        return self.main_actor.getHpr()
    
    def getPos(self) -> tuple[float, float, float]:
        return self.main_actor.getPos()
    
    def getForwardVector(self):
        return self.main_actor.getQuat().getForward()
    
    def rotateTo(self, h=None, p=None, r=None):
        """Donne au champ de force une nouvelle rotation."""
        if h : self.main_actor.setH(h)
        if p : self.main_actor.setP(p)
        if r : self.main_actor.setR(r)
    
    def rotateBy(self, h=0, p=0, r=0):
        """Fait tourner le champ de force sur un axe de rotation heading ou pitch."""
        new_h = self.main_actor.getH() + h
        new_p = self.main_actor.getP() + p
        new_r = self.main_actor.getR() + r
        self.main_actor.setH(new_h)
        self.main_actor.setP(new_p)
        self.main_actor.setR(new_r)

class PanelMode(Enum):
    """
    - ACTIVATE (porte et champs) : active ou désactive le control
    - INVERT (champs) : change le sens de poussée du champ de force
    - ROTATE (champs) : change la rotation du champ de force sur l'axe donné
    - REDIRECT (champs) : réoriente le champ de force vers une nouvelle position
    """
    ACTIVATE = 0
    INVERT = 1
    ROTATE = 2
    REDIRECT = 3

class Panel:
    '''
    Panneau de contrôle de type Cyborg ou Alien.
    L'attribut actor est l'image du panneau dans le jeu
    L'attribut control est l'élément contrôlé par l'interaction.
    L'attrivut mode est la façon dont control est modifié par l'interaction. ACTIVATE par défaut.
    '''
    def __init__(self, name, linked_character:EntityType, control, pos, hpr=(0, 0, 0)):
        model = PATH_TO_CYBORG_INTERACTION_PANEL if linked_character == EntityType.CYBORG else PATH_TO_ALIEN_INTERACTION_PANEL
        self.actor = Actor(model)
        self.actor.setPos(pos)
        self.actor.setHpr(hpr)
        self.actor.setName(name)
        self.control = control
        self.mode = PanelMode.ACTIVATE
        self.target = None
        self.linked_character = linked_character
        self.light = createNewLight(LightType.POINT, self.actor, f'{self.actor.getName()}_light', pos=(0, 0, 1))
        self.light.hide()

    def set_mode(self, mode:PanelMode, target=None):
        """
        Définit le mode de contrôle du panneau. Par défaut, le panneau active/désactive un champ de force ou une porte.

        Les modes sont :
        - ACTIVATE (porte et champs) : active ou désactive le control
        - INVERT (champs) : change le sens de poussée du champ de force
        - ROTATE (champs) : change la rotation du champ de force sur l'axe donné en target
        - REDIRECT (champs) : réoriente le champ de force vers une nouvelle position donnée en target
        """
        if mode != PanelMode.ACTIVATE:
            assert type(self.control) == ForceField, f"Panel {self.actor.getName()} : The {mode} can only be applied to forcefields."
            assert type(self.linked_character) == EntityType.CYBORG, f"Panel {self.actor.getName()} : Forcefield modification can only be performed by Cyborg."
        
        if mode == PanelMode.ROTATE:
            assert type(target) == Rotation, f"Panel {self.actor.getName()} : Expecting a Rotation axis."
            if target == Rotation.R or target == Rotation.IR: # not an assertion because the code will run without an issue anyway.
                print(f"Panel {self.actor.getName()} : miss-use of my set_mode method. Roll axis does not change forcefield orientation.")
        elif mode == PanelMode.REDIRECT:
            assert type(target) == tuple[float, float, float], "Expecting coordinates of a point to look at."
        elif target: # not an assertion because the code will run without an issue anyway.
            print(f"Panel {self.actor.getName()} : miss-use of my set_mode method. No target expected.")
        
        self.mode = mode
        self.target = target
        # TODO : a change_push_power from the alien would be so cool but hard to implement


class DoorType(Enum):
    LEGERE = 1
    LOURDE = 2

class Door:
    '''
    Porte de type Lourde ou Légère.
    Les noms des fonctions liées à l'activation doivent être consistants avec ceux des champs de force,
    car ces deux classes peuvent être contrôlées par des panneaux avec la même logique.
    '''
    def __init__(self, door_type:DoorType, pos, hpr=(0, 0, 0)):
        model = PATH_TO_PORTE_LEGERE if door_type == DoorType.LEGERE else PATH_TO_PORTE_LOURDE
        self.actor = Actor(model)
        self.actor.setPos(pos)
        self.actor.setHpr(hpr)
        self.type = door_type
        self.can_be_activated = False
        self.activated_on_our_side = False
        self.activated_at_distant = False # si la porte a été activée par l'autre client
        self.is_open = False

        if DEBUG_OPEN_ALL_DOORS:
            self.activated_on_our_side = True
            self.open()

    def enable_activation(self):
        """Indique qu'un joueur est à porté et peut ouvrir la porte en pressant la touche d'interaction."""
        self.can_be_activated = True

    def disable_activation(self):
        """Indique qu'aucun joueur n'est à porté."""
        self.can_be_activated = False

    def is_activable(self):
        """Vérifie si suffisament de joueurs tentent d'ouvrir la porte"""
        return self.can_be_activated

    def activate(self, active=True):
        """Indique si la porte a été ouverte de ce côté. En attente des données de HOST pour l'ouvrir effectivement."""
        if active and self.is_activable():
            self.activated_on_our_side = True
            if DEBUG_MAIN_LOOP_LOGS:
                print(f"** {self.type} activated.")

    def is_active(self):
        return self.activated_on_our_side
    
    def open(self):
        if self.type == DoorType.LEGERE and (self.activated_at_distant or self.activated_on_our_side) or \
            self.type == DoorType.LOURDE and self.activated_at_distant and self.activated_on_our_side:
            self.force_open()

    def force_open(self):
        """Méthode de débug permettant d'ouvrir la porte même si c'est une porte lourde n'étant pas activée des deux côtés"""
        if not self.is_open:
            self.actor.setZ(self.actor.getZ() + 2.5)
            self.is_open = True
            if DEBUG_MAIN_LOOP_LOGS:
                print(f"** {self.type} opened.")
    
    def close(self):
        if self.is_open:
            self.actor.setZ(self.actor.getZ() - 2.5)
            self.is_open = False
    
    def getHpr(self) -> tuple[float, float, float]:
        return self.actor.getHpr()
    
    def getPos(self) -> tuple[float, float, float]:
        return self.actor.getPos()

# Functions

class LightType(Enum):
    SPOT = 0
    AMBIANT = 1
    POINT = 2
    DIRECTIONAL = 3

def createNewLight(light_type:LightType, source, light_name, pos=(0, 0, 0), attenuation=(1, 0, 1), color=(1, 1, 1), intensity=1, direction=(0, 0, 0)):
    """
    create a light of the given type attached to the given source
    
    Optionnal inputs
    ----------------
    light_type (str) : the type of the light among PointLight, AmbientLight, SpotLight.
    source (Node) : the panda3D's object to which the light is bound.
    light_name (str) : the name of the light node.
    pos (tuple[float]) : position of the light. (0, 0, 0) on default
    attenuation (tuple[float]) : manage how the light gradually fade of with distance. (1, 0, 1) on default.
        Refer to https://docs.panda3d.org/1.10/python/programming/render-attributes/lighting for more informations.
    color (tuple[float]) : set a rgb color to the light. (1, 1, 1) on default. 
    intensity (float) : how powerful the light is. 1 on default.
    direction (tuple[float]) : if the light has a direction, define it.
    """
    if light_type == LightType.SPOT:
        light = Spotlight(light_name)
        lens = PerspectiveLens()
        light.setLens(lens)

    elif light_type == LightType.AMBIANT:
        light = AmbientLight(light_name)

    elif light_type == LightType.POINT:
        light = PointLight(light_name)

    elif light_type == LightType.DIRECTIONAL:
        light = DirectionalLight(light_name)
        light.setDirection(Vec3(direction))

    r, g, b = color
    light.setColor((r*intensity, g*intensity, b*intensity, 1))

    if light_type != LightType.AMBIANT and light_type != LightType.DIRECTIONAL: # ambient light has no attenuation, as it comes from everywhere
        light.attenuation = attenuation

    light = source.attachNewNode(light)
    x, y, z = pos
    light.setPos(x, y, z)
    return light
