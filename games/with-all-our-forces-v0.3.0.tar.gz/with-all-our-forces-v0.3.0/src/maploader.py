'''
Ce fichier contient tous les éléments nécessaires au chargement des éléments 3D du jeu.

Author : Romain, Raphaël, Matthew
Date : 11/01/2026
Python version : 3.13
'''

from panda3d.core import NodePath, BitMask32
from direct.actor.Actor import Actor

from src.objects import PNJ, ForceField, Door, DoorType, Panel, EntityType, createNewLight, LightType
from src.constants import *

class MapLoader:
    '''
    Cet objet gère le chargement et déchargement des différents niveaux.
    '''
    def __init__(self, showbase):
        self.render = showbase.render
        self.loader = showbase.loader
        self.pos_end_level = ((0, 0, 0), (1, 1, 1))

        self.rooms_to_load = {1:True, 2:True, 3:True, 4:True, 5:True}                              # Dictionnaire des niveaux à charger (les clefs correspondent au numéro des niveaux)
        self.current_level = 0                                                     # suit la salle qui est render
        #self.checkpoint = Vec3(0,0,0)
        self.TempNodePath = NodePath("temp_root")  # noeud vide qui sert juste d'atache temporaire au autre node path TODO : jamais utilisé, why ?
        self.salles_np = self.render.attachNewNode("salles_root")

        # toute les liste d'element contenue dans le fichier
        self.list_forcefield :list[ForceField] = [] 
        self.list_generator :list[Actor] = [] 
        self.list_panel:list[Panel] = []
        self.list_porte:list[Door] = []
        self.list_pnj:list[PNJ] = []

        self.room = {'core room':None, 'start sas':None, 'end sas':None} # TODO : start sas is just the previous end sas. Is it actually useful ?


    def _render_level(self):
        """Render un niveau et y définit les collisions. C'est mal de faire deux choses en même temps dans la même fonction mais là j'ai pas d'idées"""
        self.room['core room'].reparentTo(self.salles_np)
        if self.room['start sas']:
            self.room['start sas'].reparentTo(self.room['core room'])
        if self.room['end sas']:
            self.room['end sas'].reparentTo(self.room['core room'])
        for door in self.list_porte:
            door.actor.reparentTo(self.room['core room'])
        for panel in self.list_panel:
            panel.actor.reparentTo(self.room['core room'])
        for pnj in self.list_pnj:
            pnj.actor.reparentTo(self.salles_np)
        for generator in self.list_generator:
            generator.reparentTo(self.room['core room'])

        # Définit les collisions AVANT le reparantage des champs de force
        self.room['core room'].setCollideMask(BitMask32.bit(0))

        for forcefield in self.list_forcefield:
            forcefield.main_actor.reparentTo(self.room['core room'])


    def _clear_level(self):
        """Vide et décharge les informations du niveau précédent"""
        self.salles_np.getChildren().detach()

        for door in self.list_porte:
            door.actor.cleanup()
        self.list_porte.clear()

        for forcefield in self.list_forcefield:
            for sub in forcefield.sub_actors_list:
                sub.cleanup()
            forcefield.main_actor.cleanup()
        self.list_forcefield.clear()

        for panel in self.list_panel:
            panel.actor.cleanup()
        self.list_panel.clear()

        for pnj in self.list_pnj:
            pnj.actor.cleanup()
        self.list_pnj.clear()

        for generator in self.list_generator:
            generator.cleanup()
        self.list_generator.clear()


    def set_next_level(self):
        print("loading next level...")
        match self.current_level:
            case 0: self.set_level_1()
            case 1: self.set_level_2()
            case 2: self.set_level_3()
            case 3: self.set_level_4()
            case 4: self.set_level_5()
            case _: print("There is no more level.")


    def set_level_1(self):
        """Met en place tous les éléments du niveau 1"""
        if self.current_level != 1:
            self._clear_level()

        if self.rooms_to_load[1]:
            self.room['core room'] = self.loader.loadModel(PATH_TO_ROOM1)
            self.room['end sas'] = Actor(PATH_TO_SAS)
            self.room['end sas'].setPos((19.5, 4, 0))
            # portes
            end_of_level1_door = Door(DoorType.LOURDE, (17, 4, 0))
            end_of_sas_door = Door(DoorType.LOURDE, (22, 4, 0))
            corridor_door = Door(DoorType.LEGERE, (10.5, -1, 0), (-90, 0, 0))
            self.list_porte.append(end_of_level1_door)
            self.list_porte.append(end_of_sas_door)
            self.list_porte.append(corridor_door)
            # generateur champs force
            self.list_generator.append(Actor(PATH_TO_GENERATOR))
            self.list_generator[0].setPos((10.5, -18, 1.5))
            # champs de force
            corridor_forcefield = ForceField("corridor_forcefield", (10.5, -18, 1.5), 4, (0, 0, 0))    # vrais force 2.5
            self.list_forcefield.append(corridor_forcefield)
            # panneaux
            self.list_panel.append(Panel("end_level1_cyborg_panel", EntityType.CYBORG, end_of_level1_door, (16.5,6.5,0)))
            self.list_panel.append(Panel("open_corridor_door", EntityType.CYBORG, corridor_door, (13.16,0.03,0), (-50,0,0)))
            self.list_panel.append(Panel("active_corridor_forcefield", EntityType.ALIEN, corridor_forcefield, (7.85103,-17.4065,0), (-15.302,0,0)))
            self.list_panel.append(Panel("end_level1_alien_panel", EntityType.ALIEN, end_of_level1_door, (16.5,1.5,0)))
            # lumières
            AmbientLightGlobal = createNewLight(
            LightType.AMBIANT, self.room['core room'], 'AmbientLightGlobal',
            color=(0.8, 0.8, 0.7), intensity=1.06
            )
            correctionLight = createNewLight(
                LightType.DIRECTIONAL, self.room['core room'], 'correctionLight', intensity=1.5     # paramètres à optimiser
            )
            self.render.setLight(AmbientLightGlobal)
            self.render.setLight(correctionLight)

        # Set the end-level position
        self.pos_end_level = ((18,1.5,0), (22,6.5,4))
        
        self._render_level()
        self.rooms_to_load[1] = False
        self.current_level = 1
        return self.room['core room']


    def set_level_2(self):
        """Met en place tous les éléments du niveau 2"""
        # self.salles_np.setLightOff(self.AmbientLight_test_1)                    # turn off the previous light
        self._clear_level()

        if self.rooms_to_load[2]:
            self.room['core room'] = self.loader.loadModel(PATH_TO_ROOM2)
            self.room['core room'].setPos((31,4,0))
            self.room['start sas'] = self.room['end sas']
            self.room['start sas'].setPos((-11.5,0,0))
            self.room['end sas'] = Actor(PATH_TO_SAS)
            self.room['end sas'].setPos((11.5,0,3))
            # IA
            # .. aucunes
            # portes 
            end_of_level1_door = Door(DoorType.LOURDE, (-14,0,0))
            start_of_level2_door = Door(DoorType.LOURDE,(-9,0,0))
            start_of_level2_door.force_open()
            end_of_level2_door = Door(DoorType.LOURDE, (9,0,3))
            end_of_sas_door = Door(DoorType.LOURDE, (14,0,3))
            forcefield_door = Door(DoorType.LEGERE, (-0.5,-2.25,0))
            self.list_porte.append(end_of_level1_door)
            self.list_porte.append(start_of_level2_door)
            self.list_porte.append(end_of_level2_door)
            self.list_porte.append(end_of_sas_door)
            self.list_porte.append(forcefield_door)
            # generateur champs force
            self.list_generator.append(Actor(PATH_TO_GENERATOR))
            self.list_generator[0].setPos((2, -2.5, 0))
            self.list_generator[0].setHpr((0, 90, 0))
            # champs de force
            forcefield_elevator = ForceField("forcefield_elevator", (2, -2.5, 0), 1, (0, 90, 0)) # vrais force 0.75
            forcefield_elevator.open()
            self.list_forcefield.append(forcefield_elevator)
            # panneaux
            self.list_panel.append(Panel("forcefield_elevator_door_panel", EntityType.CYBORG, forcefield_door, (-2.39,-4,0), (-45,0,0)))
            self.list_panel.append(Panel("end_level3_alien_panel", EntityType.ALIEN, end_of_level2_door, (8.5,-2.5,3)))
            self.list_panel.append(Panel("end_level3_cyborg_panel", EntityType.CYBORG, end_of_level2_door, (8.5,2.5,3),))
            # lumières
            # self.AmbientLight_test_1 = createNewLight('AmbientLight', self.room[7], 'AmbientLight_test_1') # set AmbientLight_test_1 the nodepath to the light object of the same name, reapparent it to room[3] (nodepath of salles_np)

        # end of level area
        self.pos_end_level = ((40.5,1.5,3), (44.5, 6.5, 7))

        self._render_level()
        self.rooms_to_load[2] = False
        self.current_level = 2
        return self.room['core room']
    

    def set_level_3(self):
        """Met en place tous les éléments du niveau 3"""
        # self.salles_np.setLightOff(self.AmbientLight_test_1)                    # turn off the previous light
        if self.current_level != 3:
            self._clear_level()

        if self.rooms_to_load[3]:
            self.room['core room'] = self.loader.loadModel(PATH_TO_ROOM3)
            self.room['core room'].setPos((61,4,3))
            self.room['start sas'] = self.room['end sas']
            self.room['start sas'].setPos((-18.5,0,0))
            self.room['end sas'] = Actor(PATH_TO_SAS)
            self.room['end sas'].setPos((18.5,0,0))
            # IA
            self.list_pnj.append(PNJ(((46, -5, 4), (76, 13, 4)), (61,4,4)))
            # portes
            end_of_level2_door = Door(DoorType.LOURDE, (-21,0,0))
            start_of_level3_door = Door(DoorType.LOURDE, (-16,0,0))
            start_of_level3_door.force_open()
            end_of_level3_door = Door(DoorType.LOURDE, (16,0,0))
            end_of_sas_door = Door(DoorType.LOURDE, (21,0,0))
            self.list_porte.append(end_of_level2_door)
            self.list_porte.append(start_of_level3_door)
            self.list_porte.append(end_of_level3_door)
            self.list_porte.append(end_of_sas_door)
            # generateur champs force
            # .. aucuns
            # champs de force
            # .. aucuns
            # panneaux
            self.list_panel.append(Panel("end_level2_cyborg_panel", EntityType.CYBORG, end_of_level3_door, (15.5,2.5,0)))
            self.list_panel.append(Panel("end_level2_alien_panel", EntityType.ALIEN, end_of_level3_door, (15.5,-2.5,0)))
            # lumières
            # self.AmbientLight_test_1 = createNewLight('AmbientLight', self.room[7], 'AmbientLight_test_1') # set AmbientLight_test_1 the nodepath to the light object of the same name, reapparent it to room[3] (nodepath of salles_np)
        
        # end of level position
        self.pos_end_level = ((77.5,1.5,3), (81.5,6.5,7))

        self._render_level()
        self.rooms_to_load[3] = False
        self.current_level = 3
        return self.room['core room']
    

    def set_level_4(self):
        """Met en place tous les éléments du niveau 4"""
        # self.salles_np.setLightOff(self.AmbientLight_test_1)                    # turn off the previous light
        self._clear_level()

        if self.rooms_to_load[4]:
            self.room['core room'] = self.loader.loadModel(PATH_TO_ROOM4)
            self.room['core room'].setPos((89,4,3))
            self.room['core room'].setHpr((180,0,0))
            self.room['start sas'] = self.room['end sas']
            self.room['start sas'].setPos((9.5,0,0))
            self.room['end sas'] = Actor(PATH_TO_SAS)
            self.room['end sas'].setPos((0,9.5,21))
            self.room['end sas'].setHpr((90,0,0))
            # IA
            # .. aucunes
            # portes 
            end_of_level3_door = Door(DoorType.LOURDE, (12,0,0),(180,0,0))
            start_of_level4_door = Door(DoorType.LOURDE,(7,0,0),(180,0,0))
            start_of_level4_door.force_open()
            end_of_level4_door = Door(DoorType.LOURDE, (0,7,21),(90,0,0))
            end_of_sas_door = Door(DoorType.LOURDE, (0,12,21),(90,0,0))
            small_housse_door = Door(DoorType.LEGERE, (-3.44228,1.25,5.20833),(180,0,0))
            self.list_porte.append(end_of_level3_door)
            self.list_porte.append(start_of_level4_door)
            self.list_porte.append(end_of_level4_door)
            self.list_porte.append(end_of_sas_door)
            self.list_porte.append(small_housse_door)
            # generateur champs force
            self.list_generator.append(Actor(PATH_TO_GENERATOR))
            self.list_generator[0].setPos((0, 0, 23))
            self.list_generator[0].setHpr((0, -90, 0))
            # champs de force
            BIG_forcefield_elevator = ForceField("BIG forcefield_elevator", (0, 0, 23), 3, (0, -120, 0)) # vrais force 2.5
            self.list_forcefield.append(BIG_forcefield_elevator)
            # panneaux

            self.list_panel.append(Panel("", EntityType.CYBORG, small_housse_door, (4.5,-1,6.25),(-42,0,0)))
            self.list_panel.append(Panel("cyborg BIG elevator redirecteur", EntityType.CYBORG, BIG_forcefield_elevator, (-6.5, 2, 5.20892),(180, 0, 0)))
            self.list_panel.append(Panel("Cyborg end of level pannel", EntityType.CYBORG, end_of_level4_door, (-2.5,6.5,21),(90,0,0)))

            self.list_panel.append(Panel("alien BIG elevator activator", EntityType.ALIEN, BIG_forcefield_elevator, (-6.5, 0, 5.20892),(180, 0, 0)))
            self.list_panel.append(Panel("alien end of level pannel", EntityType.ALIEN, end_of_level4_door, (2.5,6.5,21),(90,0,0)))

            # lumières
            # self.AmbientLight_test_1 = createNewLight('AmbientLight', self.room[7], 'AmbientLight_test_1') # set AmbientLight_test_1 the nodepath to the light object of the same name, reapparent it to room[3] (nodepath of salles_np)

        # end of level area
        self.pos_end_level = ((86.5,-7.5,24), (91.5, -3.39169, 28))

        self._render_level()
        self.rooms_to_load[4] = False
        self.current_level = 4
        return self.room['core room']
    

    def set_level_5(self):
        """Met en place tous les éléments du niveau 5"""
        # self.salles_np.setLightOff(self.AmbientLight_test_1)                    # turn off the previous light
        self._clear_level()

        if self.rooms_to_load[5]:                                                    # laod et render la salle celon si a était déja était load ou pas                                               # load et render la salle celon si a était déja était load ou pas
            self.room['core room'] = self.loader.loadModel(PATH_TO_ROOM5) # TODO : pos relative to salle_np : (52,4,0)
            self.room['core room'].setPos((49.5,-30.5,-6))
            self.room['start sas'] = self.room['end sas'] # TODO : Au départ ce sas était chargé une nouvelle fois.
            self.room['start sas'].setPos((39.5,25,30)) # TODO : attention ces coordonnées étaient relatives à core room, ça peut foutre la merde.
            self.room['start sas'].setHpr((90,0,0))
            self.room['end sas'] = None
            # self.room['end sas'] = Actor(PATH_TO_SAS)
            # self.room['end sas'].setPos((11.5,0,3))
            # IA
            for i in range(4):
                for j in range(8):
                    self.list_pnj.append(PNJ('Trap AI 1', ((4.5, -53, -6), (94.5, -8, -6)), (14.5 + j*10, -45.5 + i*10, -6)))
            # portes 
            end_of_level4_door = Door(DoorType.LOURDE, (39.5,27.5,30), (-90,0,0))  # TODO : est-ce qu'on a vraiment besoin de charger plusieurs fois ces portes ?
            start_of_level5_door = Door(DoorType.LOURDE, (39.5,22.5,30), (-90,0,0)) # elles sont chargées par le niveau 2 déjà
            self.list_porte.append(end_of_level4_door)
            self.list_porte.append(start_of_level5_door)
            # generateur champs force
            self.list_generator.append(Actor(PATH_TO_GENERATOR))
            self.list_generator[0].setPos((45, 0, 33))
            self.list_generator[0].setHpr((90, 0, 0))
            # champs de force
            forcefield_transporter = ForceField("forcefield transporter", (45, 0, 33), 9, (90, 0, 0))
            forcefield_transporter.enable_activation()
            forcefield_transporter.activate()
            self.list_forcefield.append(forcefield_transporter)
            # panneauxà
            self.list_panel.append(Panel("forcefield activator", EntityType.ALIEN, forcefield_transporter, (41,8,30),(-90,0,0)))
            # lumières
            # self.AmbientLight_test_1 = createNewLight('AmbientLight', self.room[7], 'AmbientLight_test_1') # set AmbientLight_test_1 the nodepath to the light object of the same name, reapparent it to room[3] (nodepath of salles_np)

        # end of level area
        self.pos_end_level = ((-50,-2.5,30), (-45, 2.5, 34))

        self._render_level()
        self.rooms_to_load[5] = False
        self.current_level = 5
        return self.room['core room']
