#!/usr/bin/env python3
'''
Lanceur du jeu. Double-cliquable et exécutable sous Linux.
'''

from src.main import main

main()
